# Changes

Reel's versions were renumbered 0.1.1–0.1.9 (they were 0.1–0.9; the
tags are `reel-0.1.1` … `reel-0.1.9`).

## 5.1.10-riscos24 and Reel 0.1.30 (2026-10-30): live streams that keep going, the sound back after buffering, devkit 0.2.21, NEON subtitles

- **riscos-reelhwaccel devkit 0.2.21** (0.2.19 and 0.2.20 too;
  `.riscos-deps` moved to v0.2.21): an h264_vchiq video starts without
  the 2 s wait some clips had (the first picture 1-5 cs after the first
  packet on a Pi 4); a seek starts a new
  VideoCore decoder, so no picture from before the seek can turn up after
  it; a decoder that stops answering holds a close up 3 s rather than 9.
  Patches and code unchanged; vcdec.h and the libraries replaced.
- **Reel: the sound no longer stops for good after buffering** (TubeSearch's
  handoff: Chris Hughes, a CM4, YouTube through TubeSearch, the picture and
  the sound as two inputs).
  - When the sound ran dry while the network caught up, a bit of sound
    short of one of StreamManager's blocks was still waiting in reelcore,
    so the "sound device isn't playing" check saw sound queued, and the
    clock not moving, and after a second turned the sound off for the rest
    of the film. It now looks only at what StreamManager itself holds: run
    dry isn't stalled.
  - A SharedSoundBuffer stream that still won't play once it has sound is
    started again (up to 3 times a minute) before Reel goes on without it.
  - The sound from an address of its own (yt-dlp's best video and best
    sound, TubeSearch's two HLS playlists or DASH addresses) that fails or
    ends early while the picture goes on, once FFmpeg's own reconnecting
    has given up, is opened again (up to 5 tries, waiting 1, 2, 4 and 8 s
    between them) and carries on from where it got to; sound already read
    is dropped.
  - Tests, mutation-checked: `sound_gap_test` (the sound's input quiet for
    3 s, with StreamManager playing again or needing a new stream), and
    net_test's sound cut half way with its server then away for a while
    (`httpserve.py`'s "cutonce" files).
- `tests/host/run.sh` takes riscos-mesa's OpenGL headers from the devkit,
  as it does its EGL ones (a host without ARM OpenGL headers couldn't
  build ffegl_test).
- **Reel: live streams with the picture and sound apart play** (Chris's
  log: YouTube's Heathrow Airport live stream from TubeSearch, on a CM4:
  one picture, then none, the sound on its own for 40 s, then no sound).
  - Each playlist starts 6 segments back, but the sound's segments were
    shorter, so the sound started 5 s after the picture: by the sound's
    clock every picture was late, and the VideoCore gave every one back.
    The input that starts earlier is now dropped up to where the other
    starts (the picture from a keyframe there), and the sound's packets
    are timed on the picture's timeline (each was measured from its own
    input's start).
  - The reader counted its read-ahead from the last picture shown, which
    stood still while none were: it looked 10 s ahead with nothing in
    hand, so on RISC OS (one core, threads run only while Reel gives them
    time) it was hardly given time, the picture never caught up and the
    sound ran dry. It counts from the clock when that's further on, and
    an empty queue always gets the reader time. The log's net figures say
    where from (`ahead of N`).
  - net_test: a live stream as two playlists, the sound starting 7 s
    later (the first picture where the sound starts); 40 s of every
    picture thrown away (the reader counts from the clock). Both
    mutation-checked.
- **Reel: a live stream whose playlist can't be reloaded is opened again**
  rather than taken for its end (the owner's log: AcornSSL's connections
  failing after 28 minutes of YouTube's Heathrow live stream). The picture's
  input (or the one input with both) is joined again where its playlist
  now starts, from a keyframe after what was read, up to 5 tries waiting 1,
  2, 4 and 8 s; the sound's own input already was. net_test: a live
  playlist answered 503 three times (`httpserve.py`'s "failmid" files),
  mutation-checked.
- **Reel: subtitles and the stats panel blended with NEON** (instruction
  profiles: a 1080p H.264 film with subtitles and the panel, 100 pictures).
  - Into 32bpp (Reel's sprite path and ReelEGL, and whenever the overlay
    is hidden): 8 pixels at a time, the layer's columns gathered for a
    scaled one. 543 M instructions to 76 M: about 4.7 M a picture, a tenth
    of all Reel's work there.
  - A scaled layer (DVD, Blu-ray and DVB subtitles' pictures) into the
    overlay's planes: the columns worked out once a placing (they were, for
    every pixel of every row, in 64-bit sums), gathered 8 at a time.
    PGS subtitles over 1080p: 51 M fewer over 100 pictures.
  - A new subtitle's colours for the overlay: clear pixels (most of the
    layer) and runs of one colour (the text, its outline) skip the 64-bit
    sums, half the work of each new subtitle (about 12 M fewer each).
  - The same pixels, exactly: `blend_test` checks both runs against the C,
    and draws 1575 pictures (text, ASS and Blu-ray subtitles, the panel on
    and off, into 32bpp at three sizes and 4:2:0 three ways) the same as a
    build with the plain C throughout (`-DREELCORE_PLAIN_LAYERS`), and as
    before the change. Mutation-checked.
- **Reel reads further ahead from the network:** 30 seconds (or 48MB),
  not 10 (or 32MB), so a connection that comes in bursts has more in hand.

- **GitHub builds check and test too** (riscos-crossdev 1.8.2's workflows;
  `.riscos-deps` moved to v1.8.2): after the build, `make check` runs
  riscos-crossdev's checks (static, stack probes, FPU level, UnixLib) on
  every program the zips carry, then `make test-build test` builds the
  same code for ARM Linux and runs the whole test rig under the image's
  qemu-arm-aligntrap: FFmpeg's, dav1d's and x264's asm tests, the decode,
  encode and scale jobs (NEON against C), faststart, and tests/host's
  scripted desktops. The host's ffmpeg (`PACKAGES`) makes the clips.
  - **`tests/qemu/aligntrap.sh` no longer falls back to the system's
    qemu-arm**, which doesn't trap: `tests/host/run.sh` run by itself
    (without `QEMU`) had been checking nothing about alignment. With `QEMU`
    unset it takes qemu-arm-aligntrap from the PATH (riscos-crossdev's),
    else `~/qemu-aligntrap/qemu-arm` (build-qemu.sh's), else stops. Run
    under the trap, every host test passes; eabiprobe_test needed the same
    `-marm -mno-unaligned-access` as the others (RISC OS's GCC never makes
    unaligned accesses; the arm-linux one did, in the test build only).
  - `tests/qemu/run.sh`: the clips with AAC sound whose names don't start
    with it (chunky_, twoaudio_) are compared loosely, like the others with
    AAC (its decoder is float); they were reported as DIFF.

- **riscos-mesa 20.3.5-17** (`.riscos-deps`, `build/SOURCES` and
  `build/SHA256SUMS` moved to it): ffplay's `-f egl` window and the EGL
  examples copy only what changed into an overlay's buffers, and
  `*Show EGL$OverlayStatus` says how the last overlay-capable surface was
  shown or why it was plotted (RDPServer's `EGL$Overlay off` included).
  Rendering is as in 20.3.5-16. Reel drives VideoOverlay itself and
  ReelEGL's picture is a work area surface, so neither changes. (ffplay's
  SDL2 is built from our own copy of riscos-mesa's SDL patches, without
  20.3.5-17's SDL additions: not needed for ffplay's Wimp window.)

## 5.1.10-riscos23 and Reel 0.1.29 (2026-10-22): devkit 0.2.18, the VideoCore's memory given back, Stop that asks, speed-ups, live streams, GitHub builds

- **riscos-reelhwaccel devkit 0.2.18** (`.riscos-deps` moved to
  v0.2.18): h264_vchiq's pictures are written by the VideoCore straight
  into the decoder's memory instead of copied out, a little quicker (82
  against 80 1080p pictures a second on a Pi 4) and with no copy kept in
  the VideoCore's memory, so up to three 1080p hardware decoders fit at
  gpu_mem=128 (one filled it). The last picture of a stream is no longer
  lost. Patches and code unchanged; vcdec.h and the libraries replaced.
- **riscos-reelhwaccel devkit 0.2.17** (0.2.16 too; `.riscos-deps` moved
  to v0.2.17): a finished h264_vchiq stream gives the VideoCore's memory
  back without being closed, and every hardware decoder or encoder still
  open is closed when the program exits. The FFmpeg patches 0021, 0023 and
  0027 are unchanged; the headers and libraries replaced.
- **Hardware decoders closed on a crash.** RISC OS doesn't free them, so
  one left open by a crash held the VideoCore's memory, and every later
  hardware decode failed until a restart; UnixLib runs no atexit's when a
  signal ends a program.
  - Reel and ReelEGL: a crash handler always (it was only there with the
    log on) calls the new `reelcore_hw_close_all()`, then goes on as
    before.
  - ffmpeg (patch 0030): the same on SIGSEGV, SIGBUS, SIGILL, SIGFPE and
    SIGABRT, for the VideoCore's decoder and encoder and the HEVC block.
    Escape already ends it normally.
  - `vc_test` checks reelcore_hw_close_all reaches the HEVC block's
    close_all.
- **Reel and ReelEGL say why the picture isn't through an overlay**:
  Media info's Drawing line and the log now name EGL$Overlay off (which
  RDPServer sets while a client is connected) or Reel$NoOverlay, as they
  already named Hardware acceleration off or a missing module (playback
  watched through RDPServer is drawn the slower way).
- **The Convert window's Stop asks ffmpeg to stop** instead of killing
  it. Killed (Message_TaskWindow_Morite), ffmpeg closed nothing, and with
  hardware acceleration its VideoCore decoder and encoder kept the
  VideoCore's memory until a restart: every later hardware conversion or
  playback failed and fell back to the slow ARM.
  - Stop, closing the window and quitting now type Escape into its task
    window (Message_TaskWindow_Input), which UnixLib raises as SIGINT:
    ffmpeg ends as on Ctrl-C, closing its codecs. Only if it hasn't ended
    8 s later is it killed; the status then says to restart before using
    hardware acceleration again. The unfinished file is deleted as before.
  - The front end takes null events only while it waits.
- **"The VideoCore has no memory left" said, at once.** The first
  message that says so (devkit 0.2.16+: "no memory left"; 0.2.15: "Nothing
  from the decoder in N cs"; the encoder: ENOSPC or ENOMEM) stops the
  conversion, instead of an error for every packet to the end, and it is
  made again all on the ARM (encoding too), the status saying that a
  restart frees memory a stopped program left there.
- Convert: a message holding an '=' (such as "gpu_mem=128") is a message,
  not taken for a -progress line.

- **Speed-ups from instruction profiles** (new: `tools/profile`, a QEMU
  plugin and a reelcore player for counting where the instructions go;
  `QEMU_PLUGINS=1 tests/qemu/build-qemu.sh` builds the QEMU for it):
  - **Subtitle outlines drawn in two passes** (row maxima, then down the
    columns) instead of testing the whole disc around every pixel: about
    120 million instructions a new 1080p subtitle line to about 20, the
    same pixels. Each change of subtitle was a hitch of 50-80 ms on a Pi 4.
  - **swscale on 32-bit ARM pads horizontal filters to 8 taps** (patch
    0028): the NEON scaler takes only multiples of 8, so filters of 4 or 12
    taps (bilinear, upscaling, bicubic shrinking past 2x, such as the
    Convert window's 480 lines) ran in C. 1080p to 480 lines: the same
    bytes, 37% fewer instructions in all.
  - **HEVC 8-bit whole-sample bi-prediction in NEON** (patch 0029,
    intrinsics): the C did it a sample at a time, 11% of a 1080p decode on
    the ARM; now 5 times less. The same pictures (framemd5), and 2.1
    million samples against the C's formula at every width and extreme.
    (Matters where the Pi 4's HEVC block isn't used.)

- **Builds on GitHub** (riscos-crossdev 1.8.1's container image and
  workflows; riscos-crossdev's handoff):
  - `.riscos-deps` pins riscos-crossdev v1.8.1, riscos-mesa v20.3.5-16 and
    riscos-reelhwaccel v0.2.15.
  - `make sources` fetches every source by itself (`build/SOURCES`, the URLs
    for a file tried in turn until one has its checksum: FFmpeg's git archive
    of n5.1.10 from this repository's `sources` release (ffmpeg.org's
    tarball is a different file), Ubuntu's archive for x264, dav1d, LAME, libogg, libvorbis and Opus;
    SDL from libsdl's GitHub tag; meson 1.5.2, which dav1d needs and the
    image hasn't, from PyPI, run from its tarball; the riscos-mesa devkit
    from its release) and checks each against `build/SHA256SUMS`.
  - `build/env.sh` takes riscos-crossdev's toolchain (`RISCOS_TOOLCHAIN`)
    when it's set, and the riscos-mesa devkit `.riscos-deps` names; the
    toolchain's elf2aif is used when ours isn't built. The UnixLib check
    accepts riscos-crossdev 1.4's build of 5.0.3.3 (the same symbols).
  - `ci/riscos-deps-hook.sh` moves the riscos-mesa devkit's checksum, and
    `third_party/reelhwaccel` with the devkit's patches, when the
    daily update workflow finds a newer release.
  - Checked: a clean clone, with riscos-crossdev 1.4's toolchain, an empty
    `dl/` and no meson, makes the four release files (the Linux tests stay
    local for now). The hook, run against the releases, gives back
    exactly the files vendored now.

- **Live streams start with more in hand** (TubeSearch's handoff: YouTube
  webcams and news that buffered straight away, and played on a second
  try).
  - Live HLS starts 6 segments behind the newest (`live_start_index`
    -6). FFmpeg's own -3 left only 6 s with 2 s segments, which a slow
    first connection used up at once.
  - A live stream (one with no length) shows its first picture only once
    4 s are read, or after 10 s at most; nothing is decoded meanwhile, so
    the sound waits too, and Reel shows it as buffering. The log says how
    much was read and how long it took.
  - `net_test`: a live playlist of 12 one-second segments, each served
    0.3 s late, starts at segment 6 and shows its first picture with 4 s
    or more read.

## 5.1.10-riscos22 and Reel 0.1.28 (2026-10-13): less address space, devkit 0.2.15, subtitle and log fixes

Reel 0.1.28 is a new release (an earlier 0.1.28, the same as 0.1.27, was
withdrawn on 2026-10-12).

- **riscos-reelhwaccel devkit 0.2.15** (0.2.14 too):
  - `hevc_hwdec` gives the HEVC block's frames back to RISC OS once they're
    let go, keeping 2 spare (`-spare_frames N`). Before, every frame it
    made stayed until the decoder closed, so after a burst (catching up, a
    seek) 4K 10-bit kept about 280MB of memory and address space for the
    rest of the film.
  - `h264_encvchiq` takes profiles by name: `-profile:v main` (numbers
    still work), and opens about 6 cs sooner with `rc_constant`.
  - Patch 0023 is the devkit's again; 0027 is its 0003, made again against
    our series.
- **Reel keeps at most 6 HEVC block pictures decoded ahead above 1080p**
  (it was up to 8 at 60 fps). Each is a 12.6MB (8-bit) or 16.6MB (10-bit)
  frame, so at 4K 10-bit that's 33MB less memory and address space while
  it plays. 6 is 100ms at 60 fps: the block only just keeps up at 4K
  10-bit, so the margin stays. (`vc_test`: 2048x1088 at 60 fps keeps 6
  waiting with every picture shown, 320x180 at 60 fps still keeps 8.)
- **The heaps ask for 128MB of address space, not 512MB** (Reel, ReelEGL
  and the ffmpeg, ffprobe and ffplay commands; patch 0002). A dynamic
  area takes logical address space for its whole maximum when it's made,
  however little is in it. Most machines' DALimit cut 512MB down to 128MB,
  but on a 4GB Pi 4 with DALimit 1GB, ReelEGL reserved 512MB holding 96K,
  and other programs then failed with "Unable to allocate logical address
  space" (seen with AddrSpace). UnixLib 5.0.3.3 adds "Reel Heap 2", "FFmpeg
  Heap 2" and so on when more is needed, so nothing is lost. The picture
  buffers' Physical Memory Pools are already made at exactly their size.
  Checked in the binaries: `__dynamic_da_max_size` is 0x8000000.
- **A subtitle file FFmpeg doesn't recognise is read as what its name
  says** (`/srt`, `/ass`, `/ssa`, `/vtt`, `/sub`, `/smi`). A Greek .srt
  whose first cue had no number before its times showed nothing: FFmpeg's
  SubRip probe wants the number. It's tried again as SubRip (in its
  character set, as before), and the log says so. Tested with that file
  in UTF-8 and in Windows-1253 (`sub_test`).
- **Reel's log says more about the video decoder each second**: packets
  given to it, pictures that came out of it out of order, the time of the
  next packet waiting, and the times of the pictures waiting. A Reel user's
  1080p H.264 film on the VideoCore went into slow motion (2-3 pictures a
  second, packets piling up) after a moment's hold-up, and the log so far
  can't say whether the decoder was starved or gave out pictures with the
  wrong times. (`vc_test` checks the counts, with one picture given out
  late by the stand-in.)

## 5.1.10-riscos21 (2026-10-12): H.264 encoded (and decoded) by the VideoCore, from the Convert window too

Reel is unchanged: 0.1.27 stays the current Reel (its programs here are
the same code). A Reel 0.1.28 tag and release went out briefly with
this and were withdrawn: they had nothing that 0.1.27 hasn't.

- **`h264_encvchiq` encoder** (riscos-reelhwaccel devkit 0.2.13, its patch
  0003 as our 0027, with the encoder renamed from its `h264_vchiq`, the
  decoder's name, so each can be asked for and told apart in messages): H.264 encoded by the Raspberry Pi's VideoCore, e.g.
  `ffmpeg -i in.mp4 -c:v h264_encvchiq -b:v 5M -c:a copy out.mp4`. Never
  the default: ask for it by name. YUV420P in (the ffmpeg command
  converts), even sizes up to 1920x1088 (1080p needs gpu_mem=128); Annex
  B out, no B frames; the SPS and PPS as extradata for MP4 and Matroska.
  Options: `b` (default 10 Mbit/s), `g`, `profile` (as a number in
  FFmpeg 5.1: `-profile:v 66`, `77` or `100` for baseline, main, high;
  the names aren't understood), `level`,
  `rc_constant` (the Pi 4's firmware refuses constant bit rate, so it
  falls back to variable), `repeat_headers`, `qp_min`, `qp_max`,
  `in_buffers`, `pci_memory`, `gpu_mem_check`. On the Pi 4 (VCEncTest)
  1080p30 encodes at about 72 frames a second. The patch was made again
  against our series (configure's line moved by 0023); vcenc is in the
  same `libvcdec.a`, and `vcenc.h` is in the devkit. hevcdec 0.1.12 (a
  row-by-row benchmark way; nothing Reel uses changed). Tested by
  riscos-reelhwaccel on a fake encoder that behaves as the Pi's; here,
  built and linked (`ffmpeg -encoders` lists it).
- **Hardware acceleration in the Convert window** (!FFmpeg): an option
  that encodes the picture with `h264_encvchiq`; Speed then offers Fast,
  Normal and High quality, which set the bit rate from the picture's
  size and frame rate (0.07, 0.10 and 0.15 bits a pixel, 300k to 20M)
  and the profile (main, high, high; Quick to decode makes it
  baseline). Quality then only sets the sound's. Pictures over
  1920x1088 are refused with a message asking for a smaller Size.
  Greyed out where OS_SWINumberFromString doesn't know VCHIQ_MsgQueue.
  convert_test: the option, the Hardware menu, the command lines
  (bit rates, profiles, 4K refused and made 1080p, too wide, tiny);
  mutation-checked.
- **The Convert window decodes by hardware too** with Hardware
  acceleration ticked: an H.264 source up to 1920x1088 with
  `-c:v h264_vchiq` before the input, HEVC with `-c:v hevc_hwdec
  -output_8bit 1`. If the conversion fails with a message from the
  hardware decoder (or "Error while opening decoder"), the unfinished
  file is deleted and it converts again at once with the ARM decoding
  (the log keeps both tries); the next conversion tries the hardware
  again. The owner's Pi 4, a 1280x544 H.264 trailer to 720-line MP4:
  libx264 0.66x real time, the VideoCore encoding 2.2x (the ARM's
  decoding then the limit). convert_test: the input option, the
  refusal and the second try, the next conversion, HEVC, MPEG-4 and
  1440p left to the ARM; mutation-checked.

## 5.1.10-riscos20 (2026-10-11): UnixLib 5.0.3.3, riscos-mesa 20.3.5-16

FFmpeg's own code is unchanged since riscos19; the programs are rebuilt
with the latest UnixLib release and riscos-mesa devkit.

- **Relinked with UnixLib 5.0.3.3** (github.com/adyoull/riscos-unixlib
  release v5.0.3.3, an unofficial fork of GCCSDK's UnixLib;
  `libunixlib.a` sha256 e24f16c3…), its fixes since 5.0.3.1: threads
  waiting inside `read()`, `write()` and stdio let the others run, `fork()`
  with threads running, `getservbyname_r` and friends, `swprintf`'s `%ls`,
  exit codes 128-255, the heap's areas, and `LLONG_MIN` (it was an
  unsigned long long, so it compared as a large positive number:
  libavutil's `av_sscanf` uses it). FFmpeg rebuilt from clean against its
  `limits.h`. PThreadTicker stays 0.03 (the same module) and the pthread
  block 640 bytes. `tools/check-unixlib.sh` checks for 5.0.3.3's library.
- **riscos-mesa 20.3.5-16** (replacing 20.3.5-12) for ReelEGL, ffplay,
  ffmpeg's EGL output and the EGL examples. ReelEGL full screen with
  Vsync now gets 20.3.5-13's non-blocking swap
  (`eglSwapWouldWaitRISCOS`): the picture converted, then swapped once
  the vsync is under 3 ms away, rather than waiting in the swap with
  nothing else running. 20.3.5-14 and -15's NEON drawing, shader
  compiler and depth code speed up `videocube` and ffplay's GL output.
  ffplay -f egl and videowin show video pixel for pixel on EX0 EY0
  desktops, as before; videocube (freeglut) gets the window scale.

## Reel 0.1.27 (2026-10-11): subtitles in Greek, Cyrillic and more, found in Subs; volume keys

From George Tsaousis and André Timmermans on the ROOL forum.

- **Relinked with UnixLib 5.0.3.3 and riscos-mesa 20.3.5-16**, as
  FFmpeg riscos20 (above).
- **Subtitle files in Windows' code pages are shown** (George's Greek
  .srt showed nothing at all): FFmpeg drops every line of a text
  subtitle that isn't UTF-8, so reelcore now reads the file itself and,
  if it isn't UTF-8 (nor UTF-16 with its mark, nor binary), turns it
  into UTF-8 from a code page: guessed (Greek Windows-1253, Cyrillic
  1251, Turkish 1254, else Western 1252) or chosen from the new
  Subtitles > Character set menu (also UTF-8, Central European 1250),
  kept in Choices (`subtitle_charset`); choosing one reads the file
  shown again. `reelcore_set_subtitle_charset`,
  `reelcore_subtitle_charset_used`, `reelcore_charset_name`;
  tools/mkcharsets.py makes the tables.
- **Greek, Cyrillic and more letters drawn**: subtitle text stays UTF-8
  (`reelcore_subtitle_text` now gives UTF-8) and the subtitle font
  (tools/mksubfont.py, DejaVu Sans Bold) adds Latin Extended-A,
  Romanian's comma letters, Greek, Cyrillic, curly quotes, dashes, the
  ellipsis, the euro and notes (506 characters; about 1.4 MB more in
  the program).
- **Subtitle files found as VLC finds them**: beside the video with its
  name and more (film/el/srt, film_English/srt), and in a Subs or
  Subtitles directory beside it (or Subs.film). The exact name is shown
  first; files in Subs not named for the video are listed on the menu,
  not shown. The log says what was found, or where Reel looked. The
  Subtitles menu is there whenever a video is open (with the count).
- sub_test: Greek, Cyrillic, Western and Turkish files guessed and
  shown, drawn; chosen as another set read again; Greek as UTF-8 shows
  '?'s. reel_test: Film.el.srt (Greek) shown, Subs' Film.en.srt and
  Other.srt listed, Film2.srt not; Character set > Cyrillic and back,
  saved in Choices. Mutation-checked.
- **ReelEGL on a 180 dpi desktop** (EX0 EY0): the picture is the
  size it is at 90 dpi, matching the desktop's text and icons, using
  riscos-mesa 20.3.5-16's window scale: EGL chooses it
  (`eglWindowScaleRISCOS`: 2 when twice the size fits;
  `*Set EGL$WindowScale 1` keeps pixel for pixel) and shows each pixel
  2x2, so converting costs no more than at 90 dpi. Window size's Actual
  size is the video at the desktop's dpi. Subtitles, the stats and the
  volume through the overlay are drawn twice as big there too. Full
  screen is unchanged. reel_test: Actual size twice the OS units, the
  surface the video's own size shown 2x2.
- **Loop takes effect at once**: turned on while a file plays, Reel goes
  round again at its end (it was only from the next file opened).
  `reelcore_set_loop`. vc_test: on part way through, round once; off
  again, it ends.
- **+ and - change the volume** (in 5% steps of the bar; = and _ too),
  shown on the picture for a moment, so it can be changed full screen.
  reel_test.
- **Full screen at start** (the icon bar menu, kept in Choices): a video
  opened with no Reel window open goes full screen at once. reel_test:
  saved, and the video playing isn't changed.

## 5.1.10-riscos19 (2026-10-06): speed-ups

From a survey of where the time goes on a Pi (docs:
optimisation-survey), and the owner's 4K tests on a Pi 4; each change
peer reviewed, each with a host test that fails without it.

- **HEVC with all-default weight tables** (patch 0024): x265 and others
  send a weight table on most P/B slices even when every weight is
  1 << denom with no offset. Weighted prediction then gives exactly what
  plain prediction gives at about twice the cost; such slices now use
  plain prediction (a quarter of an x265 HEVC decode). hevc_weights_test
  wraps the weighted functions: none called for default slices, still
  called for real ones (fades, brightness changes, and tables rewritten
  with FFmpeg's CBS so each term of the test decides some slice:
  hevc_reweight); framemd5 against the x86 FFmpeg.
- **HEVC with skip_loop_filter** (patch 0025): pictures whose filtering
  is skipped (all, non-key, non-reference) no longer have their
  boundary strengths worked out. hevc_skipbs_test, and framemd5 against
  the x86 FFmpeg for every skip_loop_filter.
- **VP9 and AV1 honour skip_loop_filter and skip_frame** (patch 0026,
  dav1d's `dav1d_riscos_set_skip`): they ignored them, so Reel falling
  behind couldn't make them cheaper. VP9: the loop filter skipped per
  frame; frames skipped only in runs to the next keyframe. AV1:
  deblocking, CDEF and loop restoration skipped per frame, and dav1d's
  own frame skipping, both changeable while decoding. Once frames others
  refer to are skipped, both skip to the next keyframe whatever
  skip_frame becomes, rather than decode spoilt pictures. skipcheck.py,
  skip_switch_test.
- **Devkit 0.2.11**: only its hevc_hwdec patch changed (patch 0023):
  `skip_frame` passed on, and the read-only option `skipped`.
- **Devkit 0.2.10** (hevcdec 0.1.11, with 0.1.10's audit fixes): a
  use-after-free and a DPB overrun in hevc_hwdec, size changes part way,
  the brightest pixels of halved 10-bit no longer black, each frame's
  cache cleaned once; patch 0023 is its new hevc_hwdec patch.
- **riscos-mesa 20.3.5-12** (the tagged release, replacing 7pre12) for
  ReelEGL, ffplay, ffmpeg's EGL output and the EGL examples: EGL fixes
  from riscos-mesa's code audit (a context drawing into a freed buffer
  after a resize short of memory, work area surfaces over 4096 pixels,
  eglMakeCurrent flushing), overlay fixes, faster shaders. The host
  EGLImage test runs on its libraries.
- The devkit's reelcore (and the EGL examples) has Reel 0.1.26's changes.

## Reel 0.1.26 (2026-10-06): speed-ups, \*Reel <web address>

- **\*Reel <address>** (and \*ReelEGL): !Boot and !Run set
  `Alias$Reel` (`/<Reel$Dir> %*0`), so another program can hand Reel a
  stream as it would mplayer or ffplay (StreamerGUI; asked for on the
  ROOL forum). A web address given as the file on the command line is
  played as an address (it was taken for a file name: "can't read it").
  With Reel already running, the new copy passes it on in a DataLoad; an
  address too long for the message goes in a file of addresses,
  `<Wimp$ScrapDir>.ReelAddress`. reel_test: a short and a long address
  from a second copy, and one opened by the running copy.
- **Reel$UserAgent** (ReelEGL$UserAgent): the user agent sent for
  addresses that don't come with one (yt-dlp's -j gives one), for sites
  that refuse FFmpeg's own ("Lavf/59...") with 403. run.sh checks it
  reaches the server.

Speed-ups (as FFmpeg riscos19, above, for HEVC, VP9 and AV1 on the ARM):

- **10-bit video narrowed to 8 bits in NEON** (HEVC Main 10 without the
  HEVC block, VP9 profile 2, AV1 10-bit): swscale did it in C, 8-13 ms a
  1080p picture; byte for byte the same as swscale's. halve_test.
- **Late pictures nothing refers to aren't decoded at all**: one already
  late would only be thrown away when it came out; while nothing else is
  being skipped, its packet is decoded with skip_frame nonref (as
  drop_before does for the VideoCore). slow_test.
- **VP9 and AV1 leave "keyframes only" at a keyframe**: decoding every
  frame again from any other frame gave spoilt pictures. slow_test.
- **Reel, full screen with Vsync, no longer busy-waits for the refresh**
  (OS_Byte 19, up to a whole refresh on the only core): the picture is
  converted, then plotted when the vsync counter moves, the decoding left
  until after while there are pictures in hand (with few, it waits as
  before). reel_test.
- **Reel: the bars beside a picture drawn and plotted once**, not with
  every picture. reel_test.
- **The stats panel over the HEVC block's pictures: one conversion call
  a picture** (opt3): converted into cached memory, the panel blended
  there, then written to the overlay. hevcdec cleans and invalidates the
  cache over the whole frame on every call, so converting the panel's
  area again cost a whole frame's cache maintenance: 4K 10-bit with the
  panel on took 45-50 ms a picture. vc_test: one call a picture.
- **The stats panel over the HEVC block's pictures: only the panel's
  rectangle goes through cached memory** (opt6); the rest is converted
  straight into the overlay, every part from one of the block's columns.
  All of it through cached memory (opt3) took 4K 10-bit from 9.5 to
  18 ms a picture. vc_test.
- **The HEVC block falling behind no longer locks into a slow crawl**
  (opt4, devkit 0.2.10): a due picture the block hasn't finished is left
  a moment (`hevcdec_frame_done`) rather than converted, which waited
  for it with nothing else given to the block: 4K 10-bit at 60 fps with
  the stats panel dropped to 14 pictures a second and stayed there. The
  log has the block's own figures once a second (pictures left,
  conversions that waited, cache cleans). vc_test: a stall with the
  block's latency, no conversion waits.
- **A hardware decoder that only just keeps up, with no sound, catches
  up again** (opt7): the HEVC block decodes every picture, so skipping
  can't make up time, and 4K 10-bit at 60 fps once behind (turning the
  stats panel on was enough) stayed a few tenths behind for good, nearly
  every picture given back unconverted: 9 shown a second. Behind by
  two pictures (where drop_before starts giving them back; 0.1 s, opt7,
  was too much at 60 fps: the owner's 4K test clip, P pictures only with
  a keyframe every 12, stayed 0.08-0.14 s behind, 14 shown a second)
  with nothing in hand for 0.5 s (behind judged by the picture on
  screen, opt10: the newest picture out of the block, handed out as it
  starts on it, was hardly late while those shown were 0.07-0.1 s late,
  so opt9 never slipped and stayed at 15-20 a second, even with the
  panel off again; and not again within 5 s, so a machine too slow for
  the video drops pictures rather than slowing it down), the clock is
  moved back to a
  little before the next picture, so some are decoded in hand again; the
  log counts these "clock slips". (With sound the clock can't move: the
  block would have to skip.) While a picture waits for the block, Reel
  looks again at once: sleeping 10 ms (opt6) gave the block nothing
  meanwhile. vc_test: the block only just keeping up with its latency, a
  stall: one slip, then every picture on time (without it, 55 of 150
  shown); no sleeps while a picture waits.
- **The HEVC block, behind, isn't given the pictures nothing refers to**
  (opt8, devkit 0.2.11, whose hevc_hwdec passes `skip_frame` on): while
  the last picture decoded is due more than two pictures ago, Reel sets
  skip_frame nonref, so non-reference pictures (a quarter to a half of
  most streams) never reach the block and it gets ahead again, with sound
  too; cleared once two pictures ahead. Never nonkey (keyframes only).
  The log's "HEVC block" line counts the pictures skipped. A stream with
  no non-reference pictures, and no sound, still catches up by the clock
  slip. On the way to a seek's picture, the non-reference pictures more
  than half a second before it now aren't given to the block either.
  vc_test: the block only just keeping up after a stall, with B pictures
  caught up by skipping, no slip; P only, one slip; and P only at 60 fps
  with a keyframe every 12, left under 0.1 s behind, one slip (opt9).
- **The HEVC block's pictures given back unconverted only when half a
  second late** (opt12), not two pictures late: they cost nothing until
  converted when shown, and one passed over in reelcore's queue costs
  nothing either. Behind by the block's latency (0.08 s), nearly every
  picture was given back but the odd one finished just in time: 16-18 a
  second shown where the ARM converts about 30 at 4K 10-bit. The log's
  convert time is now a picture drawn (one replaced before its refresh
  isn't converted): it read 9.5 ms at 4K 10-bit, half the 18 ms each
  conversion takes. vc_test: none given back a little late, every picture
  shown after the slip.
- **The log says where the HEVC block's time goes** (opt11): once a
  second, the pictures converted while the block was busy on the next
  one and while it was idle (ms each), the stats panel's rectangle (ms a
  picture), and the time spent giving the decoder packets. Behind, a 4K
  10-bit conversion took 16-18 ms where it took 9.5 keeping up; these say
  whether that's the block's memory traffic. vc_test: each conversion
  counted once, the panel's rectangle timed.
- **ReelEGL full screen with Vsync doesn't wait in the swap** with
  riscos-mesa 20.3.5-13 (`eglSwapWouldWaitRISCOS` now answers for the
  full screen sprite plot): the picture is converted, then swapped once
  the vsync is under 3 ms away, as Reel's sprite. 20.3.5-12 always says
  the swap wouldn't wait, so nothing changes until then. reel_test.
- **The log** (Reel$Log): FFmpeg's warnings (a damaged stream gives
  several a picture) written out once a second rather than flushed line
  by line; errors and Reel's own lines at once, and the log flushed on a
  crash. reel_test.
- **Fixes from a review of the above:** after a fall back from the HEVC
  block to the ARM, the ARM decoder skips as reelcore says it does (it
  was left thinking it was skipping, so a 4K file falling back never
  caught up: vc_test); Reel no longer polls flat out after a seek or a
  clock slip when no picture is due; ReelEGL no longer converts and swaps
  a picture again after a redraw; the stats panel's last column at an odd
  width; the log's figures start again for each file.

## 5.1.10-riscos18 (2026-10-05): fixes from a code audit

From a code audit of everything ours (reelcore, Reel, !FFmpeg's front
end, the FFmpeg patches), each change then peer reviewed. Each fix has a
host test that fails without it, unless said.

- **HEVC on the ARM no longer crashes on some streams** (patch 0016).
  Chroma whole-sample copies with uni-prediction used luma's NEON copies,
  which take 4 rows a pass; a 4:2:0 chroma block can be 2 or 6 rows (8x4,
  16x4 and 16x12 blocks, as x265's slower presets and many hardware
  encoders make), and the copy ran on down the picture. Those now use the
  C's row copies. hevc_epel_test: every width at every chroma height.
- **!FFmpeg's Convert window no longer deletes a finished conversion**
  because ffmpeg printed decoder messages along the way (a DVB recording
  starting part way: "no frame!"). Success is ffmpeg reaching the end and
  its exit status 0 (the Obey file echoes Sys$ReturnCode after it).
  convert_test.
- **Convert: the Options field takes spaces** ("-vf hflip"); **quitting
  while converting** stops ffmpeg and deletes the unfinished file (it
  waits up to 10 s for the task window to end); Stop before ffmpeg had
  started is no longer lost; an existing directory of the output's name
  isn't replaced (or deleted), an image file is asked about; the same
  file as the source is found whatever the case; !Help's text for the
  Options field fits a message. convert_test (not the directory, Stop
  early and !Help parts).
- For riscos-reelhwaccel (patch 0023, theirs): two hevc_hwdec defects
  handed over (a use-after-free when its frames outlive the decoder, and
  more than 16 DPB entries written from a bad stream). For riscos-mesa
  (the SDL2 overlay, theirs): mode changes, Wimp_ProcessKey and a second
  window, handed over.
- The reelcore fixes below are in the devkit's libreelcore and the EGL
  examples too.

## Reel 0.1.25 (2026-10-05): fixes from a code audit

- **HEVC on the ARM no longer crashes on some streams** (patch 0016).
  Chroma whole-sample copies with uni-prediction used luma's NEON copies,
  which take 4 rows a pass; a 4:2:0 chroma block can be 2 or 6 rows (8x4,
  16x4 and 16x12 blocks, as x265's slower presets and many hardware
  encoders make), and the copy ran on down the picture. Those now use the
  C's row copies. hevc_epel_test: every width at every chroma height.
- **Reel: a web address with a subtitle track no longer stops reading
  ahead** (reelcore). The reader kept the newest time of each kind of
  packet in a table of two; subtitles (the third kind) were written past
  it, over the video's end flag. net_test: an MKV over HTTP with
  subtitles.
- **The fall back to the ARM works when a hardware decoder fails at
  once.** FFmpeg 5.1 runs h264_vchiq's and hevc_hwdec's decoding inside
  send_packet, and their errors (a raw HEVC stream the HEVC block can't
  take, the VideoCore failing) came back from there, where reelcore didn't
  look: the picture froze. vc_test: the stand-in fails from send_packet
  too.
- **Opening yt-dlp's JSON with anything after it no longer hangs the
  desktop** (player/sources.c: the parser went round for ever on a
  character that can't start a value). sources_test.
- **The window menu's Picture submenu works again** (Fit, Fill, Original,
  Stretch: they were items 4 to 7, below four blank ones). reel_test.
- **Reel: the sound is set up again when it changes part way** (a DVB
  recording going from 5.1 to stereo, or 48 to 22.05 kHz: it played at
  the wrong speed, or read channels the sound didn't have).
  sound_change_test.
- **Picture subtitle files (.sup, VobSub) show all their subtitles**:
  decoded as the picture comes to them (2 s ahead; from 10 s before after
  a seek), not all at once, when only the last 8 were kept. And a Blu-ray
  subtitle's clear now ends it (FFmpeg gives an empty rectangle, which
  was taken for nothing at all: it stayed up to 10 s). sub_test, with a
  .sup made by tests/host/mkpgs.py.
- **Full-range video other than 4:2:0 (MJPEG's yuvj422p, ...) keeps its
  range in the overlay**: swscale made it limited while Reel said full
  (washed out). panel_test.
- **Reel's Open address window no longer has the video drawn into it**
  (it's an auto-redraw window now). reel_test.
- **Full screen covers the screen after a change to a bigger mode** (the
  window's extent is set each time). reel_test checks the extent is set.
- **The overlay no longer hides a menu opened over a picture that has
  stopped coming** (a stream buffering): looked at every 20 cs, not only
  when a picture comes. (Not tested.)
- **Reel no longer takes ReelEGL's file type settings for its own**
  (`...!Reel` is the start of `...!ReelEGL`). reel_test.
- Smaller: the network reader's streams are no longer looked at through
  FFmpeg's stream list, which the reader can grow (MPEG-TS, HLS; the
  subtitle track list still is); reelcore's log goes on after a line
  longer than 1 KB, and is safe from the reader thread; after a hardware
  decoder fails, the ARM's decoder gets the fast (no deblocking) setting;
  reelcore_draw_yuv420 checks sizes against the HEVC block's cropped
  picture; the stats panel and subtitles aren't blended twice if the HEVC
  block's conversion fails part way; the subtitle cache key can't collide;
  out of memory for the first subtitle; Media info's title is the new
  file's; the stats panel reads a new video's details afresh.

## 5.1.10-riscos17 (2026-10-04): HEVC on the Raspberry Pi 4's HEVC block

- **hevc_hwdec: HEVC decoded by the Raspberry Pi 4's HEVC block** (patch
  0023, from riscos-reelhwaccel's devkit 0.2.6, with its hevcdec 0.1.8).
  Built in when `third_party/reelhwaccel` has `libhevcdec.a`
  (`--enable-libhevcdec --enable-decoder=hevc_hwdec
  --enable-hwaccel=hevc_hwdec`). FFmpeg's own hevc parses the stream and
  the block decodes each picture; 8-bit and 10-bit 4:2:0 up to 4096x4096,
  every picture exactly as `hevc` decodes it (riscos-reelhwaccel's Pi 4
  tests); `-output_8bit 1` gives 8-bit from 10-bit. Refused (ENOSYS) for
  4:2:2, 4:4:4, 12-bit and machines without the block.
- **Devkit 0.2.7** (sha256 c65b8ac5…): patch 0023 is its new hevc_hwdec
  patch (drop_before); the libraries are 0.2.6's.
- **Devkit 0.2.6** (sha256 80dbabab…): hevcdec 0.1.8 converts one picture
  while the block decodes the next (about 3 ms a picture less at 1080p,
  9–12 ms at 4K). vcdec is 0.4.2, as below.
- **riscos-reelhwaccel devkit 0.2.4** (vcdec 0.4.2, sha256 8876f366…):
  the contiguous memory vcdec claims for the VideoCore's pictures never
  includes the program's own page at &8000. Taking that page made RISC OS
  move the program to another page; ARMEABISupport 1.08 knows a program
  by that page and isn't told, so the program's record and stacks were
  left behind at quit, and a later program could stop with an EMT trap
  ("code 6"). Found by riscos-unixlib; fixed in vcdec (riscos-reelhwaccel
  r26). On RISC OS before 5.29 a pool that would include the page is
  refused and vcdec uses PCI memory instead. Patch 0021 is the devkit's
  (only its licence header changed: GPL version 2 only); patch 0022 is
  redone on it. Reel claims no contiguous memory itself.
- **riscos-reelhwaccel devkit 0.2.8** (hevcdec 0.1.9, sha256 111f82b5…):
  `output_hw` for hevc_hwdec (frames handed out unconverted, for Reel)
  and `hevcdec_frame_to_i420_half`. The devkit download has `libhevcdec`
  too: link with `-lhevcdec` after `-lavcodec`.
- **!FFmpeg's About this program window** has its values in display
  fields (grey, slabbed in), as other programs' do.

## Reel 0.1.24 (2026-10-04): HEVC on the Pi 4's HEVC block, no more EMT traps after the VideoCore

- **Reel and ReelEGL use the HEVC block for HEVC by themselves**
  (reelcore: `open_video_decoder`), with `output_8bit` (everything Reel
  draws is 8-bit). Refused at open: FFmpeg's hevc on the ARM. Refused at
  the first picture (a raw stream: ENOSYS) or failing part way: the ARM's
  decoder takes over from the same place (`hw_fallback`, as for the
  VideoCore). `REELCORE_NO_HEVC_BLOCK` (`*Set Reel$NoHEVCBlock 1`) keeps
  to the ARM. Frame skipping still applies; automatic deblocking-off
  doesn't (the block deblocks). Stats and Media info: "HEVC block
  (hardware)", "HEVC block (hevc_hwdec)". vc_test: a stand-in hevc_hwdec
  (FFmpeg's hevc, wrapped): used and asked for `output_8bit`, refused at
  open, refused at its first picture, failing part way; mutations caught.
- **HEVC on the block: each picture converted once, straight into the
  overlay** (devkit 0.2.8, hevcdec 0.1.9). With `output_hw`, hevc_hwdec
  hands out its frames unconverted (AV_PIX_FMT_HEVCDEC); reelcore keeps
  them in its queue and converts the one shown straight into the
  overlay's buffer with `hevcdec_frame_to_i420`, or, for 4K into an
  HD-sized overlay, `hevcdec_frame_to_i420_half` (the 2x2 means in the
  same pass). Before, each picture was converted into a frame and then
  copied (and halved, at 4K) into the overlay: on a Pi 4 a 4K picture now
  costs about 8 ms (8-bit) or 10 ms (10-bit) against 16–18 ms plus the
  copy. Subtitles and the stats are drawn over the converted rows as
  before. Drawing to a sprite or EGL, deinterlacing or turning, and
  stepping back use a YUV420P copy, made once a picture (`cur_frame`).
  reelcore takes at most one more picture than it wants ahead from the
  block, as from the VideoCore, so it holds few of its frames. Built with
  `-DREELCORE_HEVCDEC` when the devkit's libhevcdec.a has the calls.
  vc_test (reelcore built that way, with a stand-in for the block's
  frames): every picture drawn 1:1, halved and as 32bpp is the same as
  FFmpeg's hevc on the ARM gives, the conversions are the block's, and
  no frame is held at the end; mutations (halving off, the copy kept
  from the picture before) caught.
- **4K HEVC no longer drops to keyframes only** (seen on a Pi 4, 8-bit and
  10-bit at 40 Mbit/s). Falling behind, reelcore set `skip_frame`, and
  hevc_hwdec's inner hevc then gave the block keyframes only; at 4K the
  ARM (converting each picture out of the block, then into the overlay)
  never caught up. Devkit 0.2.7's hevc_hwdec has `drop_before`, as
  h264_vchiq has (patch 0022): the block decodes every picture and the
  late ones aren't converted. reelcore sets it for the HEVC block as for
  the VideoCore, and no longer sets `skip_frame` for it. vc_test: a slow
  machine with the HEVC stand-in drops late pictures unconverted and
  never skips (before: 0 dropped, a skip spell).
- **4K HEVC no longer stutters with the stats panel on** (seen on a Pi 4;
  found by riscos-reelhwaccel). The panel and subtitles were blended into
  the block's picture in the overlay itself, reading each byte back from
  memory that is slow to read (about 200,000 single-byte reads a picture
  for the panel). Now each layer's rectangle (overlapping ones as one) is
  converted from the block's frame a second time into cached memory,
  blended there and written over the overlay's: the overlay is only
  written, as on the other paths. The layer blend divides by 255 with a
  shift (`(m + 1 + (m >> 8)) >> 8`, exact for every value it gets), and
  the panel's colours, remade once a second, are worked out in fixed
  point rather than doubles with three divides a pixel (at most 1 level
  apart). vc_test: the panel on at scale 1 and 2, drawn 1:1 and halved,
  gives the same pictures as FFmpeg's hevc on the ARM, with two
  conversions a picture and none refused; mutations (the rectangle path
  off, its source moved, a column not written back) caught.
- **The stats panel costs less while it's shown** (Reel still slowed and
  stuttered slightly with it on). Once a second the whole panel was made
  again (every pixel blended with four divides) and turned into Y,Cb,Cr;
  now only the rows whose text or graph changed are, and the panel no
  longer gets narrower while shown (a shorter value doesn't make all of it
  again). Each picture, the panel is blended 8 pixels at a time with NEON
  from planes made ready for it (Y*a, Cb*a, Cr*a and 255-a), not a pixel
  at a time from Y,Cb,Cr,A. panel_test: an updated panel is exactly the
  same panel made afresh, in YV12 and 32bpp; the blend is exact for every
  run length 1–40, luma and chroma; mutations caught.
- **The About this program window looks like other programs'**: the
  values are display fields (grey, slabbed in, "R2"), as in a standard
  ProgInfo template, not white boxes. Reel, ReelEGL and !FFmpeg.
  reel_test checks it.
- **No more EMT traps after playing with the VideoCore** (riscos-reelhwaccel
  devkit 0.2.4, above): a program run after Reel could stop with an EMT
  trap ("code 6").

## 5.1.10-riscos16 (2026-10-02): H.264 on the Raspberry Pi's VideoCore

- **h264_vchiq: H.264 decoded by the Raspberry Pi's VideoCore** (patch
  0021, from riscos-reelhwaccel's devkit, with its vcdec library). Built
  in when `third_party/reelhwaccel` has the devkit (`--enable-vchiq`);
  FFmpeg is built as before without it. Not FFmpeg's default H.264
  decoder: `-c:v h264_vchiq` (ffplay `-vcodec h264_vchiq`). Up to
  1920x1088, Baseline/Main/High 8-bit 4:2:0; 1080p needs gpu_mem=128.
- **riscos-reelhwaccel devkit 0.2.1: the VideoCore's pictures aren't
  copied** (vcdec 0.4.1, sha256 749197ad…). h264_vchiq's frames are now
  vcdec's own picture buffers (cacheable): on a Pi 4 at 1080p the ARM's
  time in the decoder fell from about 10 ms a picture to 0.13 ms. Patch
  0021 is the devkit's new patch; patch 0022 (`drop_before`) is redone on
  top of it. reelcore asks h264_vchiq for `out_buffers` = 3 + the
  pictures it keeps (those decoded ahead for the frame rate, the one
  shown, one coming in: 9 at 25 fps, 13 at 60), and takes at most one
  more than it wants ahead, so what it holds fits the decoder's buffers
  (more would be copies). vc_test checks the `out_buffers` asked for.
- Built with riscos-reelhwaccel devkit 0.2.1 (sha256 749197ad…) in
  `third_party/reelhwaccel`.
- **`drop_before` for h264_vchiq** (patch 0022): pictures with an earlier
  pts are given back to the VideoCore unseen. Reel sets it when it falls
  behind and on the way to a seek's picture.
- **ReelHWAccel** (https://github.com/adyoull/riscos-reelhwaccel) is a new
  implementation: the VideoCore through RISC OS's VCHIQ module, with its
  own MMAL client, based on the MMAL message formats as Linux's vchiq-mmal
  driver defines them in its headers. It has none of the driver's code,
  but having used it as its reference it's treated as derived from it,
  so it has the same licence: the GPL version 2. The packages' `docs.Licences.ReelHWAccel` says so.
- **ReelHWAccel has its own project.** The hardware video decoding work
  (`reelhwaccel/`, the HEVCHW module, and the test tools
  `tools/hevcprobe`, `vchiqprobe`, `mmalprobe` and `mmaldecode` with
  their host tests) moved, with its history, to riscos-reelhwaccel
  (github.com/adyoull/riscos-reelhwaccel). FFmpeg and Reel will use its
  decoders through its devkit, as they use riscos-mesa's.

## Reel 0.1.23 (2026-10-02): H.264 on the VideoCore, long web addresses, File types as Iris does it

- **Reel and ReelEGL use the VideoCore for H.264 by themselves** (reelcore:
  `open_video_decoder`): h264_vchiq first, FFmpeg's h264 on the ARM when
  it refuses the stream (or isn't built in); if it fails part way
  (AVERROR_EXTERNAL), the ARM's decoder takes over at the next update,
  from the same place (a seek there). `REELCORE_NO_VIDEOCORE`, from
  `*Set Reel$NoVideoCore 1` (ReelEGL$NoVideoCore), keeps to the ARM.
  Frame skipping and automatic deblocking-off don't apply while the
  VideoCore decodes (it decodes every frame). Media info: "Decoder
  VideoCore (h264_vchiq)", or "h264, 1 thread (the VideoCore failed part
  way)".
- **No log in release builds**: `!Run` sets `Reel$Log` (`ReelEGL$Log`)
  to `off` unless it's already set, as the log costs a little time while
  playing. Test builds (a version with a suffix) come with that line
  commented out by `build/package.sh`, so they log as before. To log with
  a release build, put a `|` in front of the line.
- **1080p60 on the VideoCore: late pictures no longer copied** (seen on a
  Pi 4: 10 of 60 pictures a second shown, the ARM never idle). The
  VideoCore decodes every picture; what each costs the ARM is the copy
  out of its memory (about 14 ms at 1080p), and the 50 a second that
  came too late were copied and then thrown away. Patch 0022 gives
  h264_vchiq a `drop_before` option: pictures before it go back to the
  VideoCore uncopied. reelcore sets it two pictures' time behind the
  clock, and to the seek point on the way to a seek's picture.
  vc_test: a slow machine (60 ms a picture at 25 fps) with and without
  bursts, and a seek: every picture accounted for (shown, late or
  dropped), the decoder dropping some; none dropped while keeping up.
- **Fixed: H.264 on the VideoCore stuttered and jumped** (seen on a Pi 4
  with the first test build). The VideoCore hands pictures back in
  bursts (around big keyframes, and at the start), and reelcore, which
  keeps at most 12 ready, pushed the oldest out of its queue without a
  word: the picture jumped ahead. Now it takes a decoder's pictures only
  while there's room, leaves the rest in the decoder and keeps the packet
  it couldn't send yet; a picture pushed out is logged (it shouldn't
  happen). vc_test: a stand-in that gives bursts of 16 and refuses
  packets meanwhile, with a seek: every picture shown, no jumps (before
  the fix: 90 of 150 shown, 8 jumps).
- **Reel shows which decoder is at work while it plays**: the picture's
  stats (**S**) have a Decoder row, "VideoCore (hardware)", "ARM
  (software)" or "ARM (software: the VideoCore failed part way)"; Media
  info's Decoded row ends "(VideoCore)" or "(ARM)"; and so does each
  second's line in Reel's log. reelcore: `ReelCoreStats.decoder`
  (REELCORE_DECODER_ARM, _VIDEOCORE, _ARM_AFTER).
- **reelcore no longer loses a packet a decoder refuses for now**
  (`avcodec_send_packet` EAGAIN, as h264_vchiq gives while the
  VideoCore's input is full): it takes the decoder's frames and sends the
  same packet again. FFmpeg's own decoders never refused, so nothing
  changes for them.
- vc_test (host): a stand-in h264_vchiq (FFmpeg's h264 with its calls
  wrapped): every packet refused once and not a picture lost; refused at
  open; REELCORE_NO_VIDEOCORE; failing at the 40th picture and playing
  on to the end on the ARM. Mutations (no resend, no fallback) caught.
  The stats' decoder is checked too (VideoCore while it decodes, then
  ARM after the failure), and reel_test checks the panel's Decoder row.
- **File types: Never / While Reel is running / Always** (Chris on the
  ROOL forum, after Iris's choice for PDF files). The ticks now say which
  types Reel opens: unticked, it doesn't claim them at all (0.1.22 claimed
  every video type while running, ticked or not). While running: it
  claims ticked types' double-clicks (Message_DataOpen) and sets no Run
  aliases. Always: it also sets the ticked types' `Alias$@RunType_XXX`
  (and Data's RunData) and writes them to `Choices:Reel.Types` for !Boot;
  choosing another takes Reel's aliases off again and gives Data's back
  to the program that had it. The choice and ticks are kept in
  `Choices:Reel.Choices` (`open_mode`, `open_types`, `open_data`). With
  none saved yet, types whose Run alias is already Reel's mean Always
  with those ticked; otherwise While running with all ticked, as before.
- **A second copy started with a file hands it to the running one**
  (Message_DataLoad to its icon bar icon) instead of quitting with it:
  a ticked type's Run alias pointing at Reel did nothing while Reel was
  running and hadn't claimed the double-click (Chris: "nothing happens").
- The File types menu's title was cut short ("Double-click opens" is
  longer than a menu title can be): it's "File types".
- reel_test: the default sets no aliases; Always sets them and the Types
  file and keeps the other program's Data alias; unticking AVI removes
  its alias and an AVI double-click isn't claimed; While running takes
  every alias off and gives Data's back; Never claims nothing; a file from
  a second copy is taken; and a second copy started with a file sends it
  to the running one. Mutations caught.

- **Open address takes addresses up to 8191 characters** (it held 1023
  and cut longer ones off without a word: Raik on the ROOL forum). A
  googlevideo address from yt-dlp often passes 1500 characters, and
  `-g` gives two. Pasted text, dropped files and playlists had no limit;
  only the field and its copy for saved HLS playlists did.
- reel_test pastes a 3000-character address (a googlevideo-like query
  ending "END") and plays it, and run.sh checks the whole of it reached
  the test server. With the old limit: "pasted 1023 of 3042 characters".
- **tools/eabiprobe** (not in the downloads; `EABIProbe-0.1.zip` for
  testers): Raik found Iris won't start while Reel runs. ARMEABISupport
  can't be replaced while any GCCSDK program uses it ("There are still
  clients using ARMEABISupport"), so a !Run asking for a newer one fails
  then. EABIProbe reports the loaded ARMEABISupport, SharedUnixLibrary,
  PThreadTicker, VFPSupport and DDEUtils, the copies in System:Modules,
  `*ARMEABISupport_Info`'s list of programs, the tasks, and Iris's !Run
  lines and modules, then says whether any copy is newer than the one
  loaded. Host test: Raik's suspected machine (1.02 loaded, 1.05 in
  !Iris), all 1.05, an old one loaded at boot, none loaded, no Iris.

## 5.1.10-riscos15 (2026-10-01): UnixLib 5.0.3.1

FFmpeg's own code is unchanged since riscos14; the programs are relinked
with the UnixLib releases since then (riscos14 had 5.0.2).


- **Relinked with UnixLib 5.0.3.1** (github.com/adyoull/riscos-unixlib
  release v5.0.3.1, an unofficial fork of GCCSDK's UnixLib;
  `libunixlib.a` sha256 fa98152f…). Since rc8: heaps past 128 MB, and
  threads that run in programs that poll often (UnixLib's thread timer
  keeps running through Wimp_Poll, so ffplay's and SDL's threads get time
  however often a program polls), the fixes of rc9. No interface or header
  changes, so the programs were relinked and FFmpeg's libraries weren't
  rebuilt. 5.0.3.1's start-up claims a 640-byte pthread block (472 before):
  `tools/check-unixlib.sh` checks for that and for 5.0.3.1's library.
- **PThreadTicker 0.03** (from the same release) replaces 0.02 in the
  apps: it holds 5.0.3.1's new timer code (programs built with 5.0.3.1
  use 0.03 only, older ones 0.01/0.02 only; either runs its own copy if
  it doesn't find one it uses). The !Run files still ask for 0.01, as the
  module's ReadMe advises.
- Before that, the unreleased test builds were linked with UnixLib 5.0.3
  and 5.0.3.1-rc8; their notes follow, as they were.
- Not in the downloads: `tools/hevcprobe`, `vchiqprobe`, `mmalprobe`,
  `mmaldecode` and `reelhwaccel/` (the HEVCHW module) - the first steps
  towards hardware video decoding on the Raspberry Pi (ReelHWAccel), each
  with a host test.

### UnixLib 5.0.3.1-rc8 (test builds)

- **Relinked with UnixLib 5.0.3.1-rc8** (github.com/adyoull/riscos-unixlib
  pre-release v5.0.3.1-rc8; `libunixlib.a` sha256 44cb5481…, the same
  library as rc7). Since 5.0.3: `fork()` works in EABI programs (a fork
  child exiting no longer frees its parent's stack), `_exit(n)` exits with
  code n, `mmap()` offsets, and the review fixes of the rc series. The
  installed headers are unchanged (sched.h differs by a comment only), so
  FFmpeg's libraries weren't rebuilt; the programs were relinked.
  `tools/check-unixlib.sh` checks for rc8's library.
- **PThreadTicker 0.02** (from the same pre-release) replaces 0.01 in the
  apps: it updates its count of programs with interrupts off. The !Run
  files still ask for 0.01, as the module's ReadMe advises (a loaded,
  in-use older copy can't be replaced).

### UnixLib 5.0.3 (test builds)

- **Relinked with UnixLib 5.0.3** (github.com/adyoull/riscos-unixlib
  v5.0.3; `libunixlib.a` sha256 761305fa…). Its fixes: `read()` into a
  buffer on the stack could kill a program ("Fatal signal received: EMT
  trap") when the SWI wrote to a stack page not yet mapped; `ctime()`,
  `asctime()` and their `_r` forms could return a bad pointer; no build
  paths in the library's debug information. Same symbols and installed
  headers as 5.0.2, so FFmpeg's libraries weren't rebuilt, only the
  programs relinked. `tools/check-unixlib.sh` (run by package.sh) now
  also checks the toolchain's libunixlib.a is 5.0.3's, since a program
  linked with it can't be told from one linked with 5.0.2.

## Reel 0.1.22 (2026-10-01): the pointer hides full screen, a sound track key, file types, saved HLS playlists

Three requests from Chris on the ROOL forum:

- **The pointer hides full screen** after 2 seconds with the mouse left
  alone, and comes back as soon as it moves or a button is pressed
  (`OS_Byte 106`; the shape before is put back). Checked on every null;
  while it's hidden and paused, nulls come a few times a second so a
  move is still seen. Shown again on leaving full screen, before an
  error box and on quitting. `*Set Reel$NoHidePointer 1` keeps it.
- **#** chooses the next sound track (files with more than one; after
  the last, the first again), as the Sound track menu does.
- **File types** on the icon bar menu: the video file types MimeMap knows
  (from avi, mp4, m4v, mkv, webm, mov, mpg, ts, vob, wmv, flv, ogv, 3gp;
  each type once), ticked when a double-click of that type starts Reel
  (its `Alias$@RunType_XXX` is Reel's). Choosing one sets or clears the
  RunType now and writes `Choices:Reel.Types`, an Obey file !Boot runs, so
  it lasts. While Reel is loaded it still claims any video double-clicked
  (Message_DataOpen), ticked or not.
- **Data files named like a video** (film/mp4: MP4, MKV and WebM have no
  settled RISC OS filetype, and files from other computers arrive as
  Data): while Reel is loaded it claims a double-clicked Data file whose
  name ends in a video extension. File types > "Data, by name" sets
  `Alias$@RunType_FFD` to `Obey <Reel$Dir>.RunData %*0`, a new Obey file
  that picks the extension with `SetEval … RIGHT n` and starts Reel, or
  passes any other Data file to the RunType there before (kept in
  `Alias$ReelOldRunData`; given back when unticked). Pi report: an AVI
  ticked worked, MP4 didn't.
- reel_test: full screen, the pointer hidden after 2 s left alone, back
  when the mouse moves, hidden again, back on leaving full screen; # with
  a two-track file (second, then first); File types > AVI ticked (the
  RunType and the Types file) and unticked. Mutations caught for each.
- **A saved HLS playlist with relative names** (Raik on the ROOL forum: a
  master .m3u8 saved from a site names its streams "hlsv.m3u8", relative
  to where it came from): dropped on Reel, it opens Open address asking
  "The address this playlist came from". Given that, Reel writes
  `<Wimp$ScrapDir>.ReelHLS` with each stream and segment name (and the
  `URI="..."` of `#EXT-X-MEDIA` and similar lines) made whole from it -
  `//host/x`, `/x` and `x` as a browser would, the address's own query
  left off - and plays that, titled by the dropped file. Text that isn't
  an http(s) address is refused with a message; Escape or Close forgets
  the playlist and puts the window's usual label back. Playlists that
  already name whole addresses play as before.
- reel_test: a saved master naming "hlsv.m3u8" dropped, the window asks,
  "not an address" refused, `<server>/live/master.m3u8?session=1` given:
  the scrap file names `<server>/live/hlsv.m3u8` and it plays (322x184).
  sources_test: what counts as relative, and the three kinds of join.
- Linked with UnixLib 5.0.3.1 and carrying PThreadTicker 0.03, as
  riscos15 (below).

## 5.1.10-riscos14 (2026-09-30): MP4 files from the Convert window, properly this time

- **Forum report (Raik):** reducing a 720p video to 480p with the Convert
  window's default settings made an unusable file, while his own command
  line worked. The window's command is fine; the fault was in patch 0020
  (riscos13), which every MP4/M4A with `-movflags +faststart` goes
  through on RISC OS. It closed and reopened the output's AVIOContext
  while movenc kept its old pointer and wrote the index (the moov)
  through freed memory. That worked only when the allocator handed the
  same block back; otherwise the file had no index ("moov atom not
  found") or ffmpeg crashed.
- **Patch 0020, reworked:** the AVIOContext stays the same object; only
  the file under it is closed, the data shifted in place through one
  read-write opening, and the trailer written through that opening. FLV
  (`-flvflags add_keyframe_index`) used the same path and is fixed too.
- **tests/qemu/faststart.sh** repeats every in-place run with an
  allocator that never reuses freed memory (`tests/qemu/nofree.c`): the
  old patch crashes there for MP4, MOV, M4A and FLV; the new one gives
  files byte-identical to the usual way. FLV added.
- **Convert window:** when a conversion fails, the unfinished file is
  deleted (as after Stop), so a broken file isn't left to be mistaken
  for a video. The status line says so.

## 5.1.10-riscos13 (2026-09-29): files over 2GB, MP4 files from the Convert window, and more options

- **Files over 2GB** (up to 4GB-1, the RISC OS limit): linked with
  **UnixLib 5.0.2** (github.com/adyoull/riscos-unixlib v5.0.2, tested on a
  Pi with a 3GB file). FFmpeg's configure already builds with
  `-D_FILE_OFFSET_BITS=64`; libavformat was rebuilt from clean against
  5.0.2's headers (`sys/stat.h`, `sys/mman.h`, `unistd.h`), so its file
  protocol seeks past 2GB (`lseek64`) and sees the 64-bit size
  (`__unixlib_fstat64`). Up to riscos12, UnixLib 5.0.1 stopped at 2GB-1
  (EOVERFLOW). build-apps.sh gives Reel, the front end and the examples
  `-D_FILE_OFFSET_BITS=64` too. `tools/check-unixlib.sh` now also checks
  that every program with FFmpeg's file protocol calls `__unixlib_fstat64`.

- **Forum report:** converting big_buck_bunny_480p.mpg to MP4 (the Convert
  window adds `-movflags +faststart`) failed at the end: "Unable to re-open
  … output file for shifting data" and "This file is already open"
  (&108C2). To move the index to the front, FFmpeg opens the output a
  second time for reading while it is still open for writing, and RISC OS
  refuses that.
- **Patch 0020** (libavformat/mux_utils.c, `ff_format_shift_data`): on RISC
  OS the output is closed, the data shifted along in place through one
  read-write opening (from the end backwards, 256 KB at a time: the file
  protocol's largest write; `truncate=0`), then opened again for writing
  without truncating, at the end of the shifted data. Elsewhere only when
  the second opening fails, or with `FFMPEG_SHIFT_IN_PLACE` set (tests).
- **Convert window: an Options field** for more ffmpeg options, as on the
  command line (e.g. `-vf hflip`, `-r 25`, `-metadata title=…`). They go
  after the window's own output options, before `-progress`, so they win.
  It must start with an option, be one line, and not add `-i`. Tab moves
  to it; greyed out while converting, like Trim. The window is 56 OS units
  taller. convert_test: the Obey file carries them; the three refusals.
- **tests/qemu/faststart.sh** (in run-all.sh): MP4 (5 chunks), MOV and
  M4A made in place are byte for byte what the usual way makes. Mutations
  caught: opening with truncation (an empty file), 1 MB writes (EIO).

## Reel 0.1.21 (2026-09-30): subtitles, chapters, frame steps, turned videos, 4K, and keeping up

- **Subtitles, drawn into the picture** (so they show over the hardware
  overlay), in reelcore:
  - Tracks are the file's subtitle streams and subtitle files:
    `reelcore_subtitle_tracks`/`_track_name`/`_track`,
    `reelcore_set_subtitle_track`, `reelcore_add_subtitle_file`,
    `reelcore_show_subtitles`, `reelcore_subtitle_text`. A stream marked
    default or forced is shown at the start (as mpv).
  - The chosen stream's packets are read with the rest (`pkt_kind` 2) and
    decoded as they come. Choosing it again seeks to the picture shown. A
    file is read whole.
  - Text (SubRip, ASS/SSA, mov_text, WebVTT): ASS override blocks
    dropped, \N and \h made plain, UTF-8 to Latin-1 (curly quotes,
    dashes and ellipses made plain). It's drawn white with a round black
    outline, centred near the bottom, wrapped to 92% of the width. The
    font is DejaVu Sans Bold at 22, 32 or 46 px, chosen for about 5% of
    the height shown (`reelcore/sub_font.h`, made by
    `tools/mksubfont.py`).
  - Pictures (DVD, PGS, DVB): palette to premultiplied RGBA, placed on
    their canvas scaled to the picture; an empty one ends the one before.
  - Events are kept in order of start, not doubled after a seek. Text is
    kept (up to 8192 events); only the last 8 pictures are kept.
- **Layers:** the stats panel and the subtitle share one "layer" code:
  placed per draw with a scale, nearest pixel, blended in
  `reelcore_draw_pixels` and in `reelcore_draw_yuv420`'s row copies.
  `reelcore_set_yuv_scale()` (Reel sets it from the overlay's size) makes
  both the size they'd be in the window. The panel's margin now scales
  with it too.
- **Chapters:** `reelcore_chapters`, `_chapter_start` (as
  `reelcore_position`), `_chapter_title`, `_chapter_at`. Reel has a
  Chapters menu (the time and the title of each), and Page Down / Page Up
  (the next; back to this one's start, or the one before within 2 s).
  Media info says how many.
- **Frame steps:** `reelcore_step` (paused: the next picture) and
  `reelcore_step_back` (a seek to 1.5 pictures before, exact). Playing
  again after a step seeks to the picture shown, so the sound starts
  there. In Reel: `.` and `,`, which pause first. `paused_show()` shows
  the picture after a seek or step while paused (up to 5 s of decoding).
  Choosing a chapter while paused uses it too.
- **Stepping back is quicker** (Pi report: frame stepping slow):
  - The pictures before are kept (up to 10, `hist`): the ones decoded on
    the way to a step back's seek (`bstep`), and each picture a step
    forward leaves. The next steps back take one at once
    (`reelcore_step_back` returns REELCORE_NEW_FRAME); only every 10th
    decodes from the key frame.
  - Every seek (not just steps) skips decoding non-reference pictures
    (most B-frames) more than 0.5 s before its picture
    (`skip_frame = AVDISCARD_NONREF`), restored when it's reached. From
    8 s into a clip with its key frame at 0: 116 pictures decoded instead
    of 203.
  - Reel shows the hourglass while it decodes for more than 0.3 s, up to
    20 s.
- **The sound kept to its queue when the video falls far behind** (the
  same 4K log: "StreamManager_AddBlock refused a block: Buffer full",
  15 s queued, then "the sound device isn't playing; carrying on without
  sound"). With the video at key frames only, reading raced ahead to find
  them, and every sound packet read was decoded and queued at once. Sound
  packets now wait as packets (`apk`, like the video's `vpk`) and are
  decoded only while less than `ahead` is queued; the decoder's flush at
  the end comes after them. slow_test has a heavy run (0.4 s a picture,
  key frames every second): at most 0.27 s queued (0.65 s before).
- **4K through the hardware overlay** (Pi report: a 3996x1730 trailer
  kept blanking the screen, and didn't with Hardware acceleration off;
  the log said "only 2 of 3 buffers (GPU memory)"):
  - Reel makes the overlay at most about 1920x1088's pixels (and 2048
    each way): bigger videos are halved (4K to 1998x864). That's a
    quarter of the GPU memory and of the display's scaling work.
  - `reelcore_draw_yuv420` takes a size of half the frame or less: yuv420p
    is halved row by row with NEON (`reelcore_halve_plane`), and 4:4:4
    has luma halved once and colour twice, all NEON (swscale's
    conversion took 176 ms a picture at 3996x1730). Other formats go
    through swscale scaling. Subtitles and the stats follow the overlay's
    size.
  - panel_test: halved YV12 is the 2x2 averages; 4:4:4 halved has luma
    equal to the averages and colour within 1. A mutation (4:4:4 through
    swscale) is caught.
- **Turned videos:** a stream's display matrix (phone videos) turns the
  picture 90/180/270 degrees through the same filter graph as yadif
  (transpose, or hflip+vflip). The size is swapped for 90/270. Media info
  has a Turned line. `REELCORE_NO_ROTATE` turns it off.
- **Reel:**
  - Subtitle files beside a local video (film/srt, /ass, /ssa, /vtt;
    Unix film.srt) are added when it opens. A subtitle file dropped on
    Reel is added to what's playing.
  - V hides or shows the subtitles; J goes to the next track (then none).
  - A Subtitles menu (None, then the tracks).
  - Media info has a Subtitles section.
- **Tests:**
  - New `sub_test`: MKV with a default SubRip track and chapters, an .srt
    added to an MP4, an ASS file, YV12 at 1x and 2x, frame steps, a
    display matrix of 90 degrees.
  - reel_test phases: a .srt dropped on the window (the text in the
    picture), V twice, J, `.` `.` `,` and Space.
  - panel_test's margin scales with the overlay.
  - Mutations caught: no rotation, no override-tag stripping, no layers
    in YV12.

- **Keeping up: deblocking off by itself.** Before any frames are skipped,
  reelcore turns off the H.264 deblocking filter (about a quarter of the
  decoding) when pictures take more than 0.9 of the time between them, or
  the video is 0.1 s behind with decoding above 0.75 of that time. It is
  tried on again every 10 s while decoding keeps up (after 20, 40 … 160 s
  when a try had to go straight off again), and comes back for good below
  0.6. The timers use real time (the clock goes back at a loop or seek).
  Media info's Frame skipping row and a "Keeping Up" row on the stats say
  when; `*Set Reel$NoAutoFast 1` (`REELCORE_NO_AUTOFAST`) stops it. On the
  Pi a 1080p 4:4:4 or high-bitrate 1080p file gains most; a 4K trailer
  still skips frames. slow_test: a video a little too slow keeps up with
  no skipping (5 skip spells without); a stall on an easy video, and a
  video just too slow, are tried and settle correctly.
- **Stats and subtitles readable full screen through the overlay.** They
  were drawn at the screen's size and shrunk into the frame a pixel at a
  time (a 720p frame on 1920x1200: 0.67), which dropped whole rows and
  columns of each letter. Now each is drawn in a font of the size it is
  seen, in the frame's own pixels, with no scaling: the panel from DejaVu
  Sans Mono Bold at 9-33 px (bigger on screens over 900 lines: about 18 px
  at 1200), subtitles from DejaVu Sans Bold at 16-56 px (5.2% of the
  frame's height). panel_test at scales 0.5, 1 and 2; sub_test: the same
  text height shown 1x and 2x. Confirmed on a Pi.

## Reel 0.1.20 (2026-09-29): files over 2GB, a steady clock, 60 fps, and stats on the picture

- **Files over 2GB** play (up to 4GB-1): linked with UnixLib 5.0.2 and
  FFmpeg riscos13's libraries (see riscos13). sources.c no longer takes
  ftell's -1 as a length for a text file it can't measure.

- **reelcore's `clock_smooth()` is now a timer steered by the sound**
  (0.1.19 snapped to each of the sound's readings). The clock is the
  system timer.
  - Each time the sound's reading moves, where the sound really is is
    taken as the reading plus half the time since the last look (the step
    came somewhere in between).
  - The clock moves a quarter of the way there, and jumps if they're more
    than 100 ms apart.
  - As before, it never runs more than 1.5 steps past the last reading and
    never goes backwards.

  Pictures come evenly, and a sound device running at a slightly different
  rate from the timer is followed.
- **`ReelCoreStats`:** `pace_sum`/`pace_n` (how evenly pictures are handed
  out) and `sync_err_sum`/`sync_err_n` (the clock against the sound at
  each step). Media info shows both: "evenly to N ms" on Pictures shown,
  and "steered to within N ms of it" on Clock. !Help has a "Keeping time"
  section.
- **The overlay no longer waits for the vsync.** A picture that comes
  before the overlay's last switch has happened used to wait for the
  vsync there and then (OS_Byte 19), up to 16.7 ms with nothing decoded
  meanwhile; at 60 fps that was most of the drawing time. Now it waits
  as `S.ov_pending`, and Reel carries on decoding and tries again on the
  next pass (without sleeping). If a newer picture is due first, the
  newer one is shown. Media info's Drawing line and the log count both
  ("N waited, N replaced").
- **Media info opens beside the player** (right, then left, else below or
  above) where there's room, so it doesn't cover the picture and hide the
  overlay. Otherwise it goes where it always did. `info_open` also had a
  block of 8 words for Wimp_GetWindowState, which writes 9: fixed.
- **Stats on the picture** (S, or the window menu): YouTube's "Stats for
  nerds" rows (Video / Source, Viewport / Frames, Current Res / Drawn,
  Volume, Codecs, Color, Connection Speed, Network Activity and Buffer
  Health with a graph of the last minute each, Timing, Date), drawn *into*
  the picture by reelcore, so it shows over the Pi's hardware overlay
  (which covers anything on the screen).
  - `reelcore_set_panel()` / `reelcore_panel_size()`: rows of label and
    value, optional graphs. `reelcore_draw_pixels` blends it 1:1 at the
    picture's top left; `reelcore_draw_yuv420` blends it into the YV12
    rows as they're copied (in cached memory, then written once), scaled
    by `yuv_scale` to undo the overlay's scaling.
  - The font is DejaVu Sans Mono Bold at 15 px, as 8-bit coverage
    (`reelcore/panel_font.h`, made by `tools/mkpanelfont.py`; Latin-1).
    Its licence is in `third_party/dejavu/Licence` and the zips' Licences.
  - **Tests:** `panel_test` (RGB both byte orders, YV12 at 1x and 2x,
    nothing changed outside the panel, graph bars, off again exactly as
    before). reel_test: S on, the text in the picture and the picture
    as reelcore draws it; S off.
- **Stats on the picture, for a file:** Connection Speed, Network Activity
  and Buffer Health only for a web address. For a file, Reading (Mbit/s
  from the file) and Ready (pictures decoded ahead, sound queued) instead,
  without graphs. Codecs and the container use the short names ("h264
  (High) / aac (LC)", "QuickTime / MOV"). reel_test checks the rows for a
  file and for a web address.
- **No more late pictures from slow ones at 60 fps** (a Pi 4 ReelEGL log of
  test60_720p_60s: 1–8 late a second in stretches, decoding 2x real time on
  average).
  - reelcore skipped a picture as late whenever the next one was due too.
    A picture that took longer than 16.7 ms to decode left two due at
    once, so one was thrown away. Now a picture is skipped only if the next
    one was due more than a picture's time ago (at most 40 ms); otherwise
    both are shown, one straight after the other.
  - `fill()` decoded up to 8 pictures in a row before a due one was shown
    (to fill up after a skip), which made the next ones late. It now stops
    when a picture is due.
  - Decoding ahead is by time: 0.13 s of pictures, 3 to 8 (8 at 60 fps, 4
    at 30, 3 at 24/25; it was always 3). QMAX 12.
- **Media info's "N in all"** late count starts again when the file is
  played again from the end, or you seek to the start.
- **clock_test:** a 60 fps clip with decoding taking time (6 ms, and 8
  pictures a second at 24 ms): 0 late, up to 8 decoded ahead. Mutations
  caught: the old skip rule (6–7 late), decoding in a row (20–32 late),
  3 ahead.
- **reel_test:** a new phase `P_OVLWAIT` holds the vsync counter still.
  Pictures wait without blocking or sleeping, none are drawn another way,
  and one is shown once the vsync comes. The fake overlay counts two
  switches in one vsync (tearing). Media info must not overlap the player.
  Mutations caught: the blocking wait put back, sleeping while a picture
  waits, and Media info opening in the old place.
- **clock_test:** sound reported in 2048-frame blocks, a 30 fps clip at
  44.1 kHz.
  - Pictures evenly spaced to 0.4 ms, the sound followed to within 0.5 ms,
    including with the sound hardware 1% fast.
  - Sleeping as Reel does: 3.7 ms, 3.6 ms.
  - Mutations caught: the raw clock (29 late, 16 ms uneven), and the timer
    without steering (25 ms drift with the sound 1% fast).

## Reel 0.1.19 (2026-09-29): 30 fps video shows all 30 pictures

- **The fix:** 30 fps video with 44.1 kHz sound showed only 21–26 pictures
  a second on a Pi 4, with 5–9 skipped as "late", although decoding kept
  up easily (2.2x real time) and Reel slept 40% of the time. The same
  happened in Reel and ReelEGL, with and without the overlay.
- **The cause:** the sound is the clock, and StreamManager reports what
  has been played a whole block (2048 sample frames) at a time. At
  44.1 kHz that's a 46 ms step, but a 30 fps picture is due every 33 ms.
  At each step the next picture was already due too, so the one before it
  was thrown away as late. (25 fps at 48 kHz lost fewer: 23.8 of 25 shown
  in earlier logs.)
- **reelcore:** `clock_smooth()` runs the sound clock on by itself
  between steps from where the last step put it. It never goes more than
  1.5 steps past the last reading (if the sound stops, so does the clock)
  and never backwards. It starts again after a seek, a resume or a speed
  change. Detecting a stalled device still uses the raw reading.
- **Tests:** `tests/host/clock_test.c`.
  - The fake sound device reports playback in 2048-frame blocks
    (`FAKE_AUDIO_BLOCK`), with a 30 fps, 44.1 kHz clip.
  - Now: 149 pictures in 5 s, none late.
  - Without the smoothing: 123 pictures and 25 late, the Pi's numbers.

## 5.1.10-riscos12 (2026-09-29): RISC OS names in the current directory

- **`ffmpeg -i holiday/mp4 small/mp4` now means the files holiday/mp4 and
  small/mp4 in the current directory**, as in the rest of RISC OS. UnixLib
  reads a name with no filing system, disc or directory prefix as a Unix
  one, so before this it opened the file "mp4" in a directory "holiday".
  (A forum report of ffmpeg "doing nothing" on the command line, with
  names written the way !Help showed them.)
  - FFmpeg patch 0019 (`libavformat/riscos_filename.h`, `file.c`):
    `ff_riscos_relative_name()` recognises these names. The rules: one
    `/`; no `.` after it; no prefix (a filing system, `:`, `$ @ ^ % & < \`);
    and after the `/`, an extension of a format FFmpeg knows (from any
    muxer or demuxer). Such a name is opened as `@.holiday/mp4`, which
    UnixLib leaves alone.
  - `Films.holiday/mp4` works the same way. Unix names (`clip.mp4`,
    `dir/clip.mp4`, `videos/clip`) and full RISC OS names are unchanged.
  - It applies to opening, checking, deleting and renaming files, in
    ffmpeg, ffprobe and ffplay alike.
- !Help: how names are read, with examples of each kind, and when to
  start a name with `@.`.
- Tests: `tests/host/riscos_name_test.c` (24 names, host gcc with the
  sanitizers).

## Reel 0.1.18 (2026-09-28): hardware acceleration (video overlays)

- **Hardware acceleration** on the window menu (on by default, saved in
  Choices as `hardware_acceleration`): with the VideoOverlay module, each
  picture is copied as YV12 (the decoder's yuv420p planes, row by row;
  other formats through swscale at the same size) into a hardware overlay,
  and the display scales it and converts it to RGB. No swscale conversion,
  scaling or plotting per picture. Both !Reel and !ReelEGL talk to
  VideoOverlay themselves. riscos-mesa's EGL overlays are RGB, 1:1, for
  visible-area surfaces; ReelEGL's picture is a work area surface.
- Built from riscos-mesa's Pi 4 measurements (ovltest):
  - Create is used as the probe (Vet fails on the Pi).
  - 3 buffers, else 2 when the GPU is short of memory.
  - It waits for a vsync when none has passed since the last switch (no
    tearing).
  - Overlay memory is only ever written (it is uncached: reads are slow).
  - After a mode change the old overlay is destroyed and a new one made.
- The Pi's overlays are "Basic" (over everything). The overlay is hidden,
  and the picture drawn as before:
  - while a window or menu overlaps the picture (Reel walks the window
    stack up from its window, at every picture);
  - while paused and at the end;
  - around error boxes and the "carry on" question.
- **Fallback:** whenever there's no overlay, the picture is drawn exactly
  as before, with no message:
  - the option off, `Reel$NoOverlay`, or `EGL$Overlay off`;
  - no module;
  - Create refused;
  - a buffer that can't be mapped;
  - a size outside the scaling limits;
  - any SWI error (not tried again until the size, colours or mode change).
- The menu item is shaded without the module and says "(in use)" when it
  is. Media info's Converting and Drawing lines say what's happening.
  `!Run` loads VideoOverlay if it's in !System (quietly).
- reelcore: `reelcore_draw_yuv420()` (planar 4:2:0 at the frame's size,
  write-only row copies; `REELCORE_YUV_709` / `_FULL` for the ModeFlags).
- Tests: reel_test (and the SharedSoundBuffer and EGL builds) with a fake
  VideoOverlay. The steps: Create refused (drawn as before, not retried),
  a mode change bringing it back, the selector (YV12, ModeFlags &6000,
  3 buffers), pictures going through the overlay and not the sprite, the
  buffer equal to the frame's YV12, Fit placement and clipping,
  RedrawWindow in redraws, a window over the picture (hidden, drawn as
  before), uncovered, pause and resume, only 2 buffers mappable, and
  switched off from the menu. Mutations (no covering check, no hiding on
  pause) are caught.

## Reel 0.1.17 (2026-09-28): web addresses and yt-dlp's output

- **Web addresses** in !Reel and !ReelEGL: http://, https:// (AcornSSL,
  loaded by !Run) and HLS. **Open address…** on the icon bar menu: a
  window to type or paste one (Ctrl-V or Paste asks the clipboard's
  holder with Message_DataRequest; the text arrives through
  `<Wimp$Scrap>`, which is deleted after). Several pasted lines play at
  once. Or drop a file: a URI (&F91) or URL (&B28) file, a text file with
  one address a line (a playlist), or an M3U (#EXTINF titles used; an HLS
  playlist is played itself). Text dragged from another program
  (Message_DataSave) works too.
- **yt-dlp's output** (`player/sources.c`): `-g`'s address, or its two
  (best video and best sound apart, recognised by YouTube's mime=video /
  mime=audio), which play together; and `-j`/`-J`'s JSON: the title
  (UTF-8 to Latin-1), requested_formats' two addresses, the site's
  http_headers and user agent, a line (or `entries`) per video for a
  playlist. Where you stopped is remembered by the page's address
  (webpage_url). A web page's own address gets "that's a web page, not a
  video", pointing to yt-dlp in !Help.
- **reelcore reads addresses in a thread of its own**
  (`reelcore_open_source`, `ReelCoreSource`): it opens the address(es)
  and reads packets up to 10 s (or 32MB) ahead, so a slow connection
  never holds up the desktop; seeks go to the thread. With
  `REELCORE_ASYNC` the open returns at once and `reelcore_update()` says
  OPENING, then READY or FAILED: what was playing carries on meanwhile,
  and with nothing playing the window opens saying "Opening". FFmpeg's
  reconnect options, a 20 s timeout, and a whitelist of protocols (file,
  http, https, tcp, tls, crypto, data, httpproxy). Closing while opening
  returns at once. Two inputs (video and sound apart) work for files too.
- The time shows "Buffering" when the reading falls behind; Media info's
  Reading line gives what's read ahead, and Title, Address and Sound from
  rows. `reelcore_net()` for programs.
- Tests: `tests/host/httpserve.py` (a local server with Range requests,
  a header log and a never-answering mode); `net_test` (async open,
  playing, a seek giving the same picture as the file, video and sound
  from two addresses and from two files, headers, a missing address,
  closing while opening); `sources_test` (host gcc with the sanitizers:
  every kind of text above); reel_test's new phases: Open address with a
  Ctrl-V paste through the scrap file, playing while the last video
  carries on, yt-dlp -g's two addresses dropped with nothing playing, and
  a web page.

## 5.1.10-riscos11 (2026-09-28): https through AcornSSL

- **https** (and TLS generally: HLS over https, rtmps, tls:) through RISC
  OS's AcornSSL module, RISC OS 5.28 and later. FFmpeg patch 0018
  (`libavformat/tls_acornssl.c`, `--enable-riscos-acornssl`): the TCP
  connection is opened as usual and its RISC OS socket (UnixLib's
  `__get_ro_socket`) handed to `AcornSSL_CreateSession`; reads and writes
  go through `AcornSSL_Recv`/`AcornSSL_Send`, non-blocking, waiting on the
  socket with FFmpeg's timeout and interrupt callback. The handshake is
  driven with 1-byte peeks until AcornSSL stops answering ENOTCONN. The
  host name is set (SNI, and the certificate must be for that name);
  AcornSSL checks certificates against its own authorities and asks in the
  desktop about one it can't verify. `AcornSSL_Close` leaves the socket to
  the tcp: context. Written from AcornSSL's documentation and source
  (ROOL's RiscOS/Sources/Networking/Fetchers/AcornSSL, doc/AcornSSL, c/api).
- !Run loads AcornSSL (quiet if it isn't there); without it, https says
  what's missing.
- Tests: `tests/host/https.sh` runs the arm-linux ffmpeg/ffprobe with a
  pass-through stand-in for the module (`tests/host/fake_acornssl.c`)
  against a local HTTP server: the calls and their order for every
  session, the host name, a whole file read (and seeked) through it, a
  60-step handshake, a failed handshake, no module, and a server that
  never answers (-rw_timeout). The real handshake needs a Pi.
- !Help: https; the stale "ffplay has no desktop front end" limit removed.

## 5.1.10-riscos10 and Reel 0.1.16 (2026-09-28): UnixLib 5.0.1 and PThreadTicker

- **Relinked with UnixLib 5.0.1** (github.com/adyoull/riscos-unixlib,
  release v5.0.1): the thread timer's code runs from the new PThreadTicker
  module when it's loaded (else from a copy in the RMA, as before), and
  its Wimp filters are now registered even for threads started before
  Wimp_Initialise (SDL's), the cause of other tasks crashing while a
  threaded program ran (confirmed on a Pi with Warzone 2100). ffplay is
  the program here with several threads; the rest mostly run one.
- **PThreadTicker 0.01 is in each app** (!FFmpeg, !Reel, !ReelEGL, the EGL
  examples), from `third_party/pthreadticker` (BSD licence, in
  docs.Licences); each `!Run` (the examples' SetUp) loads a copy merged
  into !System first, else its own. Reel's log lists its version.
- `tools/check-unixlib.sh`: package.sh refuses a program not linked with
  UnixLib 5.0.1 (the 472-byte pthread block). `tools/check-versions.sh`
  also checks the module is the released one (sha256).
- Toolchain: the Warzone GCCSDK environment with UnixLib 5.0.1's
  `libunixlib.a`, `sched.h` and `unistd.h` (docs/SOURCES.md).

## Reel 0.1.15 (2026-09-28): resizing, and a better, lighter mini player

- **Resize grip** in the bottom right corner of the window and the mini
  player (the windows have no scroll bars, so the Wimp gave them no size
  icon): dragging it is the Wimp's own size drag. The mini player keeps
  the video's shape and remembers its width (`mini_width` in Choices).
- **Window size** on the window menu: Half, Actual size, Double (of the
  video's size in screen pixels) or Fit the screen; never narrower than
  the controls, kept on the screen.
- **The mini player looks better:** big reductions are halved first in
  reelcore (2x2 averages, NEON; `reelcore_halve_plane`), then swscale
  does the rest. At a quarter size (1280 -> 320) fast bilinear alone
  skipped three pixels in four (jagged, "blocky" detail): on the Simpsons
  trailer 23.7 dB from a Lanczos reference, against 35 dB for a box
  filter, which is what halving twice is. By instruction count it should
  cost about what it replaces (it reads the whole picture, but in NEON,
  and the colour conversion is then 1:1); the log's convert ms will show. Media info's Converting line says "halved twice,
  then swscale".
- **The mini player decodes a little less:** `REELCORE_FAST_LIGHT`, the
  deblocking filter skipped on pictures nothing is predicted from (most
  B-frames): about 14% less decoding on Big Buck Bunny 720p (x86, C),
  51.7 dB from normal decoding once shown at mini size, and nothing
  carries over to the normal window. `reelcore_set_fast` takes
  `REELCORE_FAST_OFF/ON/LIGHT` (0 and 1 as before).
- Tests: `halve_test` (NEON = C over 2,600 cases, whole pictures),
  options_test (light mode), reel_test (grip, Window size, the mini
  player's grip and saved width, light decoding in the mini player only).
  The host tests' reelcore is now built with NEON, as on RISC OS.

## 5.1.10-riscos9 and Reel 0.1.14 (2026-09-28): the standard Info window

- **Info on the icon bar menu is the usual RISC OS "About this program"
  window** in !FFmpeg, !Reel and !ReelEGL: a submenu showing Name,
  Purpose, Author (Andrew Youll) and Version with its date. Reel's Info
  used to open the media info window while a video was playing; that
  stays on the window's menu (and the I key). The window is built in code
  (`common/proginfo.h`, shared by all three).
- **One place for the version numbers:** `common/version.h`.
  `tools/check-versions.sh` (run by the host tests) checks that the
  Makefile, package.sh, build-ffmpeg.sh and the !Help headers agree with it.

## 5.1.10-riscos8 (2026-09-28): Convert saves next to the original

- **Convert works straight away.** The new file goes next to the
  original by default (holiday_720/mp4 beside holiday/mkv): the name
  field is filled with the full path, so clicking Convert is enough.
  Dragging the file icon to a directory display, or typing another full
  path, still puts it elsewhere. A bare name (no directory) is refused
  with a message saying what to do.
- **The file icon always shows.** It used the sprite `file_<type>` for
  the new file's type (MP4, via MimeMap); on a machine with no sprite for
  that type the icon was blank and there was nothing to drag. It now
  falls back to `file_xxx`, the Filer's "?" icon.
- Status line and interactive help say where the file will go.

## 5.1.10-riscos7 (2026-09-28): the Convert window

- **!FFmpeg converts files from the desktop.** Click the FFmpeg icon (or
  Convert... on its menu); dropping a file on the icon still plays it.
  One window, used from the top down (`frontend/convert.c`):
  - drop a file on it: ffprobe reads it and a line says what's in it
    (codecs, size, frame rate, interlaced or not, sound, length);
  - "Convert to": For playing here (MP4 up to 720 lines, easy to decode),
    MP4 same size, Smaller file (480 lines), Sound only MP3 / AAC, each
    with a one-line description; the options under it (format, size,
    quality, speed, sound, deinterlace, quick to decode, from/to) show
    what it chose, and changing one makes it Custom; what doesn't apply
    is greyed out;
  - save the RISC OS way: drag the file icon to a directory display, or
    type a full path and press Return / click Convert; the name is filled
    in from the source's (holiday_720/mp4) and its directory is kept;
  - a progress bar, "x real time" and the time left; Stop (the unfinished
    file is deleted); then Play, Show and, on failure, the reason and
    Log. An existing file is only replaced after asking; closing the
    window or quitting while converting asks first. Interactive help for
    every part.
  - ffprobe and ffmpeg run in task windows of their own (`*TaskWindow
    -task -txt`), their output coming back as messages: the desktop
    carries on. ffmpeg's `-progress pipe:1` drives the bar.
- **ffmpeg and ffplay get patches 0015–0017**: yadif (`-vf yadif`), HEVC
  chroma and swscale's scaling to RGB32 (ffplay's drawing) in NEON.
- The devkit has Reel 0.1.13's reelcore (speed, deinterlacing, sound
  tracks, picture modes) and the patched libraries.
- Tests: `convert_test` (34-step scripted desktop: probing, presets,
  menus, saving by drag, progress, Stop, replace, done, failure, help,
  quit), and the window's ffmpeg command lines run for real by ffmpeg
  5.1 on nine cases (presets, sizes, MKV with a part, silent, interlaced
  MPEG-2, HEVC, an odd size), the results checked with ffprobe.

## Reel 0.1.13: NEON for resizing and HEVC colour (2026-09-27)

- **FFmpeg patch 0017: swscale scaling to RGB32 in NEON.** With
  `SWS_FAST_BILINEAR` to RGBA/BGRA (what Reel uses whenever the picture
  isn't 1:1: full screen, resized windows, the mini player, Fill,
  Stretch; and ffplay's direct drawing) the 32-bit ARM path was C.
  Now the fast bilinear horizontal scalers (8 outputs a step, source
  bytes through `vtbl`, down to about 1.85x) and the `yuv2rgbx32`
  output (`_1` and `_2`) are NEON. The 32 bpp colour tables can't be
  looked up in NEON, so `ff_yuv2rgb_c_init_tables` now also stores them
  as arithmetic (`SwsContext.yuv2rgb_arith`), which gives exactly the
  tables' values.
- **FFmpeg patch 0016: HEVC chroma motion compensation in NEON**
  (`put_hevc_epel`, `_uni`, `_bi`; h, v, hv; widths 2–64). FFmpeg's
  32-bit ARM NEON had luma only. The whole-sample chroma copies now use
  luma's NEON too.
- **Tests:** `hevc_epel_test` (1,900 cases against the C; four
  deliberate bugs all caught) and HEVC decodes giving the same pictures
  with NEON, with `-cpuflags 0` and on x86 FFmpeg; `swscale_rgb_test`
  (2,747 cases: the functions alone over many scales and colour
  settings, and whole pictures in the same context with and without the
  NEON functions). FFmpeg's checkasm: all 962 pass. qemu emulates NEON
  slowly, so the speed-up is for the Pi to show.
- **The log** now has, once a second, what each picture cost: decoding,
  converting (and to what size), drawing and deinterlacing, so full
  screen can be measured.
- The ffmpeg/ffplay programs get patches 0015–0017 in the next FFmpeg
  package; Reel's zip carries them in `docs.source.patches`.

## Reel 0.1.12: deinterlacing, with yadif in NEON (2026-09-27)

- **Deinterlace** (window menu: Auto, On, Off; D; remembered). reelcore
  runs FFmpeg's yadif (buffer → yadif=send_frame → buffersink, one
  picture a frame, no threads) on the pictures as they're decoded, so
  redraws, resizes and the mini player cost nothing extra. Auto makes
  the filter only at the first picture marked interlaced: progressive
  video goes straight through as before. Seeking drops what yadif held;
  at the end its last picture is flushed.
- **FFmpeg patch 0015: yadif's line filter in NEON for 32-bit ARM**
  (`libavfilter/arm/vf_yadif_neon.S`). FFmpeg 5.1 has x86 versions only,
  so ARM ran the C. Eight pixels an iteration, 16-bit sums, byte-element
  loads and stores (no alignment needed). Bit-exact: `yadif_test`
  compares it with the C on 56,064 lines (every mode, parity, edge line,
  width 1–70 and wide, every alignment; four deliberate bugs are all
  caught), and `ffmpeg -vf yadif` gives the same pictures with NEON,
  with `-cpuflags 0` and on x86 FFmpeg. The ffmpeg/ffplay programs get it
  in the next FFmpeg package; Reel has it now (its zip carries the patch
  in `docs.source.patches`).
- Media info: **Scan** (progressive / interlaced, which field first) and a
  **Deinterlacing** stats row (mode, ms a picture, pictures interlaced).
- reelcore: `reelcore_set_deinterlace`, `reelcore_deinterlace`,
  `REELCORE_DEINT_*`; stats `deinterlace`, `interlaced`, `deinterlaced`,
  `deinterlace_time`. Its filter graphs (atempo too) are made with one
  thread.
- Tests: `yadif_test`, the whole-picture yadif comparison, `deint_test`
  (Auto matches x86 FFmpeg's yadif at the same frame, Off matches the
  plain decode, seeking, progressive left alone), and Reel's menu and D
  key in `reel_test`.

## Reel 0.1.11: playback options and a mini player (2026-09-27)

- **Volume:** a green bar in the controls row; click along it. It's
  remembered (`Choices:Reel.Choices`). The bar is roughly how loud it
  sounds (the level given to SharedSoundBuffer is its square).
- **Mini player** (M, or the window menu): a small window with no title
  bar, bottom right just above the icon bar (it asks the Wimp where the
  icon bar is): the picture, Play/Pause, the position bar and Normal.
  Drag the picture to move it (remembered); double-click it, click
  Normal or press M for the normal window again. **Keep on top** (window
  menu, remembered): RISC OS has no always-on-top for ordinary windows,
  so while playing the mini player looks once a second and, if another
  window has been opened over it, comes back to the front (never taking
  the caret).
- **Vsync (full screen)**, on by default: full screen waits for the
  screen's refresh before each picture (Reel: OS_Byte 19; ReelEGL:
  eglSwapInterval 1 with a back buffer). Untick it for Direct (ReelEGL:
  `EGL_SINGLE_BUFFER`, straight into screen memory). `<App>$NoVsync`
  starts with it off (was ReelEGL's `Direct`, `ReelEGL$NoDirect`).
- **Speed** 0.5x to 2x (window menu); the sound keeps its pitch. The time
  shows e.g. "1.5x".
- **Picture:** Fit (as before), Fill (crop), Original size, Stretch.
- **Fast decode:** skips the deblocking filter, for files that are too
  much for the machine.
- **Sound track:** choose among a file's sound tracks.
- **Playlist:** files dropped together (one drag) play in turn; Shift
  adds to the list. N/P, and the Playlist submenu (with Clear the rest);
  the title shows "(2/5)". Loop loops the list.
- **Carry on:** Reel remembers where you stopped each file (the last 100,
  `Choices:Reel.Resume`) and asks whether to carry on from there.
- **A-B repeat** (A, or the window menu): set A, set B, off. The time
  shows " A" / " AB".
- The window menu is regrouped, with submenus; the time field is wider
  (hour-long files and the new marks fit); the narrowest window is 1096
  OS units.
- **reelcore:** `reelcore_set_speed` (FFmpeg's atempo; programs now link
  `-lavfilter -lpostproc`), `reelcore_set_fast`, `reelcore_volume`,
  `reelcore_audio_tracks`, `_track`, `_track_name`, `set_audio_track`;
  `REELCORE_FILL` and `REELCORE_ORIGINAL` for `reelcore_draw_pixels` and
  `ffegl_draw_surface`. The riscos6 devkit has 0.1.10's reelcore; these
  reach the devkit with the next FFmpeg release.
- Tests: `options_test` (speed, fast decoding, sound tracks, picture
  modes); `reel_test` drives all of the above through the fake Wimp in
  the Reel, SharedSoundBuffer and ReelEGL builds.

## Reel 0.1.10: reelcore and ffegl split (2026-09-27)

- **ffegl was a player core with EGL attached; now they are two
  libraries.** The name said "FFmpeg into EGL", but most of it (reading,
  decoding, the sound and clock, frame skipping, stats) had nothing to do
  with EGL, and !Reel used it with no EGL at all.
  - **reelcore** (`reelcore/`): the player core, no EGL. Everything that
    was `ffegl_*` except the two EGL calls is now `reelcore_*`
    (`reelcore_open`, `reelcore_update`, `reelcore_draw_pixels`,
    `reelcore_idle_time`, `reelcore_stats`, ...), `FFEGLVideo` is
    `ReelCore`, the flags and results are `REELCORE_*`, and
    `FFEGL_AUDIO` is `REELCORE_AUDIO`. New: `reelcore_frame_size()`, and
    `reelcore_attach()`/`reelcore_attachment()` for a layer's own state.
  - **ffegl** (`ffegl/`): only the EGL side, on top of reelcore:
    `ffegl_draw_surface()` and `ffegl_texture()` (its EGLImage state is
    kept with the video through `reelcore_attach` and freed by
    `reelcore_close`). Built `-DFFEGL_NO_TEXTURE` it has no OpenGL.
  - !Reel links reelcore only; !ReelEGL, videowin and videocube link
    reelcore and ffegl. The devkit has `libreelcore.a` + `reelcore.h` as
    well as `libffegl.a` + `ffegl.h`. `build/build-ffegl.sh` is now
    `build/build-apps.sh` (`make apps`; `make ffegl` still works).
- No change in what the players do. All host tests pass, including
  ffegl_texture against riscos-mesa's real EGL and OSMesa.

## 5.1.10-riscos6 (2026-09-27): first GitHub release

The same `ffmpeg`, `ffprobe` and `ffplay` as riscos5; what changed is
around them:

- **!FFmpeg:** `!Run`, `Task` and the EGL examples' `SetUp` load
  SharedSound, StreamManager and SharedSoundBuffer (they were only merged
  into `!System`, never loaded, so ffplay had no working sound device).
  The icon's menu has **Log** (ffplay's messages, now at verbose level,
  in `<Wimp$ScrapDir>.ffplay/log`).
- **The player library** (ffegl then; reelcore and ffegl from Reel
  0.1.10), in the devkit and the EGL examples, as in Reel 0.1.5–0.1.10: sound straight to SharedSoundBuffer
  on RISC OS (no SDL audio thread); the file read for the sound
  separately from video decoding (the trailer freeze); frame skipping
  when behind; `ffegl_debug`, `ffegl_set_log`, `ffegl_media_info`,
  `ffegl_stats` and `ffegl_idle_time`.
- `COPYING` (GPL version 2) added.

## Reel 0.1.9 (2026-09-27)

- **Sleeps between pictures.** On the Pi, Media info showed ReelEGL
  decoding the 1280x544 trailer in 23% of the time (9.6 ms a picture,
  4.3x real time), converting and drawing in under 5 ms, yet Task
  Manager showed 56%: the rest was 5200 null events a second asking
  whether the next picture was due yet.
  - ffegl: `ffegl_idle_time()` says how long the caller may sleep after
    `ffegl_update()`: 0 while there's work (fewer than 3 pictures
    decoded, sound under 0.35 s queued, a picture due), otherwise the
    time to the next picture, at most 0.1 s.
  - Reel polls with `Wimp_PollIdle` until then (whole centiseconds, so it
    wakes on or just before time; the last few ms are polled as before).
    The next pictures are decoded before sleeping, so showing one on
    time needs only the wake-up.
  - Media info's Desktop line and the log show how much of the time Reel
    was asleep. `Reel$NoSleep` / `ReelEGL$NoSleep` polls flat out.
- Test: `idle_test` plays the same clip polling every 0.5 ms and
  sleeping as Reel does (waking up to 1 cs late at random, 8 ms a
  decode): the same 150 pictures, none late, worst 4.7 ms after its time
  (flat out: up to 5 ms early), with 607 wake-ups instead of 9633.
  reel_test checks Wimp_PollIdle is used.

## Reel 0.1.8 (2026-09-27)

- **Media info window** (window menu "Media info", or I), replacing the
  File info error box, which stopped the picture while it was open. It
  stays open while playing and follows the file being played.
  - At the top, "stats for nerds", every second while playing (and on
    pause): position and clock (sound or timer) and the gap between
    them; pictures shown a second against the video's rate, late ones;
    pictures decoded a second, ms each and times real time; decoding
    load (pictures and sound); frame skipping; swscale time a picture
    and its size; drawing time a picture (OS_SpriteOp, or EGL); pictures
    and packets waiting; the sound output and queue; the reading rate;
    null events a second and the screen mode.
  - Below, from `ffegl_media_info()`: file (name, title, container,
    length, size, bit rate, streams), video (codec, profile, level,
    size, aspect, frame rate, pixel format, colours, bit rate, frames,
    decoder, B-frame reordering), audio (codec, profile e.g. HE-AAC,
    channels and layout, sample rate and format, bit rate, language,
    decoder) and the sound output.
  - Drawn with Wimp_TextOp in the desktop font; the stats are redrawn
    with Wimp_UpdateWindow (no flicker from ForceRedraw).
- ffegl: `ffegl_media_info()` and `ffegl_stats()` (running totals:
  pictures decoded and shown, decoding, sound and swscale time, sizes,
  queues, sound counts, bytes read).
- Test: reel_test opens the window with I, checks its text (codec,
  sample rate, the stats after a second of playing) and closes it.

## Reel 0.1.7 (2026-09-27)

- **The trailer froze after half a second, now with SharedSoundBuffer.**
  Reel 0.1.6's log on the Pi: the sound started (SharedSoundBuffer 0.07,
  StreamManager 0.03 and SharedSound 1.20 all loaded), played 0.51 s,
  then `queued 0.00 s ... 7 pictures waiting` for good: the clock stayed
  at 0.49 s.
  - In this file the video is read about a second ahead of its sound.
    ffegl read packets only while fewer than 7 pictures were waiting, so
    with 7 decoded pictures (all ahead of the clock) it stopped reading;
    the sound ran dry; the clock (the sound) stopped; no picture became
    due. Every build since ffegl 1 had this; the SDL stall fallback hid it
    in 0.1.3.
  - Now ffegl keeps the video packets it reads (compressed) in a queue
    and decodes them separately: the file is read as far as the sound
    needs (0.5 s queued), however far the video is ahead or however slow
    it decodes (up to 48 MB of packets).
- **Falling behind:** 0.3 s behind the clock, ffegl skips decoding
  non-reference frames (`skip_frame = AVDISCARD_NONREF`, mostly
  B-frames); 1.5 s behind, keyframes only; back to every frame once
  within 0.05 s. The log says when ("0.32 s behind: skipping
  non-reference frames"), and `ffegl_debug()` shows the packets waiting
  and the skip level.
- Tests: `chunky_h264_aac_322_184.mp4` (fragments of 1.5 s, video then
  sound) freezes 0.1.6 and plays with 0.1.7 in `reel_ssb_test`;
  `slow_test` makes decoding cost more than real time and checks that
  the pictures keep up with the sound.

## Reel 0.1.6, !FFmpeg front end log (2026-09-27)

- **Reel and ReelEGL write a log**: `<Wimp$ScrapDir>.ReelLog`
  (`ReelEGLLog`), started afresh at each start and flushed line by line.
  - Start: the build, the versions of SharedSound, StreamManager,
    SharedSoundBuffer, SharedUnixLibrary and VFPSupport (from their help
    strings, or "not loaded"), `FFEGL_AUDIO`, `SDL_AUDIODRIVER`, the
    screen mode; ReelEGL adds EGL's version and each surface made.
  - Each file opened (`ffegl_info`), the window size, pause, seek, full
    screen, mode changes, the end, close, quit, and every error box.
  - FFmpeg's messages at verbose level, with repeats folded.
  - Once a second while playing: `ffegl_debug()` (position, clock and
    which one, pictures waiting, late frames; the sound output, queued
    time, StreamManager's added/played counts, bytes waiting, refused
    blocks), plus null events and pictures shown.
  - `Reel$Log` / `ReelEGL$Log` names another file, or `off`. "Log" on
    the icon bar menu opens it (Filer_Run).
- ffegl: new `ffegl_debug()` and `ffegl_set_log()`; SharedSoundBuffer
  events (stream opened, sound starts, first refused block, reopen
  failures) and SDL's driver name are logged at verbose level; the
  stall warning includes the `ffegl_debug()` line.
- !FFmpeg: ffplay runs with `-loglevel verbose` into
  `<Wimp$ScrapDir>.ffplay/log`, and the icon's menu has "Log" to open it.
- Tests: `reel_ssb_test` and `reelegl_test` check the log's contents.

## Reel 0.1.5 (2026-09-27)

- **Still no sound on the Pi with the modules loaded.** With SharedSound,
  StreamManager and SharedSoundBuffer loaded (`*Help SharedSoundBuffer`
  shows 0.07), ReelEGL still said "the sound device isn't playing": SDL's
  RISC OS driver opened, but the sound queued with `SDL_QueueAudio` was
  never taken. SDL takes it on its own audio thread, and in a Wimp task
  UnixLib's threads only run while the task is paged in; Reel spends most
  of its time in `Wimp_Poll` or decoding.
- ffegl now gives the sound to SharedSoundBuffer/StreamManager itself on
  RISC OS, from `ffegl_update()`, in 2048-frame blocks (0.5 s kept
  queued). StreamManager plays it from interrupts, so no thread is
  involved. The clock is `StreamManager_BufferStats` (added - played).
  Seeking closes and reopens the stream. `FFEGL_AUDIO=sdl` goes back to
  SDL. This covers Reel, ReelEGL, videowin and videocube.
- Test: `reel_ssb_test` runs the Reel script with ffegl built
  `-DFFEGL_SSB` against fake SharedSoundBuffer SWIs.

## Reel 0.1.4, and !FFmpeg 5.1.10-riscos5 repackaged (2026-09-27)

- **No sound on the Pi:** SharedSoundBuffer, StreamManager and SharedSound
  were merged into `!System` but never loaded (`*Help SharedSoundBuffer`
  gave "No help found"). Nothing had asked for them.
  - SDL then fell back to UnixLib's `/dev/dsp`, which accepted the sound
    and didn't play it. Reel showed "the sound device isn't playing", and
    ffplay played silently.
  - The `!Run` files of `!FFmpeg`, `!Reel` and `!ReelEGL`, `!FFmpeg.Task`
    and the EGL examples' `SetUp` now RMEnsure/RMLoad `SSound`,
    `StreamMan` and `SSBuffer` from `System:Modules`, the same lines as
    Warzone 2100's `!Run`.
- ffegl (so Reel, ReelEGL, videowin and videocube) now asks SDL for its
  RISC OS sound driver only (`SDL_AUDIODRIVER=riscos` unless it's already
  set). If the modules are missing there's no sound device, and
  `ffegl_info()` gives SDL's reason, e.g. "no sound device: RISC OS audio:
  SharedSoundBuffer/StreamManager not loaded".
- The `!FFmpeg` zip was repackaged with the new `!Run`, `Task` and
  `!Help`. The programs in it are unchanged.

## Reel 0.1.3 (2026-09-27)

- **A sound device that doesn't play no longer freezes the picture.** On
  the Pi, a trailer with sound showed its first frame and stopped. Reel
  follows the sound clock, and that clock doesn't move while the device
  takes none of the queued sound.
  - ffegl now watches for this: if nothing queued is played for 1 s while
    playing, it stops sending sound, pauses the device and carries on
    with its timer.
  - The stall timer restarts after a seek and after a pause.
  - `ffegl_has_audio()` returns 0 then, and `ffegl_info()` says "the
    sound device isn't playing".
  - Tested with a fake device that opens but never plays: all 25 frames
    are shown, finishing after about 2 s for a 1 s clip.
- HE-AAC (the trailer's sound) decodes under the alignment-trapping QEMU,
  and so does its H.264 Main 1280x544 picture. The file itself was never
  the problem.

## Reel 0.1.2 (2026-09-27)

- **!ReelEGL:** the same player (`player/reel.c` built with `-DREEL_EGL`),
  drawing through riscos-mesa's EGL. It's a working example of
  `ffegl_draw_surface` in a real program.
  - In the window, the picture is a work-area EGL surface (fixed size, top
    of the work area) above the ordinary Wimp icons. Frames arrive by
    `EGL_KHR_lock_surface` and `eglSwapBuffers`; redraws go through
    `eglPlotSurfaceRISCOS` in the task's own redraw loop.
  - Full screen uses the whole-screen surface. It's direct into screen
    memory by default (`EGL_SINGLE_BUFFER`, "Direct" on the window menu,
    `ReelEGL$NoDirect`), otherwise a sprite plotted after vsync.
  - It links riscos-mesa's EGL and OSMesa: 28.8 MB text.
  - It passes the same scripted test as Reel, against a fake EGL: the
    frames shown, work-area surface sizes, direct full screen, no surfaces
    left over.
- Reel: the picture is refreshed only when the window is actually resized
  (not on every move), and the drawing sits behind a small internal layer
  shared by both builds.
- ffegl: `FFEGL_NO_TEXTURE` (EGL surfaces without the GL texture code).
- Reel 0.1.1's File info said "no sound" for Big Buck Bunny 720p 10s 30MB.
  That's correct: the file has no sound track.

## Reel 0.1.1 (2026-09-27)

- **!Reel, a video player for the desktop** (`player/reel.c`,
  `dist/Reel-0.1.1.zip`). It's a native Wimp app built on ffegl: an icon
  bar icon, and a window with the picture above a row of controls.
  - Controls: Play/Pause, back and forward 10 s, a position bar you can
    click, the time, and Full. Keys: Space, the arrow keys, F, Escape
    and Q.
  - Open a video by dropping it on the icon or the window. Double-clicking
    in the Filer also works while Reel is loaded, for filetypes MimeMap
    calls video/*.
  - The picture is scaled into the window by swscale (NEON), letterboxed,
    and plotted as a 32bpp sprite in the screen's colour order. The window
    can be resized.
  - Full screen is a borderless window over the whole screen.
  - Sound goes through SDL2 (SharedSoundBuffer) and is the clock. There
    are no threads of its own: decoding happens on null events.
  - The window menu has File info (codec, size, fps, sound, frames
    skipped), Full screen, Loop and Close. The icon menu has Info, Loop
    and Quit.
  - It uses no EGL or OpenGL (ffegl built with `FFEGL_NO_GL`), so it's a
    20 MB program.
  - **Test:** `tests/host/reel_test.c` drives the whole app through a
    scripted fake desktop, with real decoding under the alignment-trapping
    QEMU. It checks playing (the plotted pixels are the frame),
    pause/resume, the position bar, full screen and back, resize, a second
    file, a directory refused, and double-click claiming only video types.
- ffegl: `ffegl_info()` (a description of the streams),
  `ffegl_dropped_frames()`, and the `FFEGL_NO_GL` build option.

## 5.1.10-riscos5 (2026-09-27)

- **An icon bar icon:** double-clicking `!FFmpeg` now puts the FFmpeg icon
  on the icon bar, as well as setting up the commands.
  - Drop a video or sound file on the icon and it plays in ffplay. Each
    file gets its own window and task, and messages go to
    `<Wimp$ScrapDir>.ffplay/log`.
  - The icon's menu has Info, Full screen (plays with `-fs`) and Quit.
  - It's a small C program (`frontend/fffront.c`, `!RunImage`, 512K); only
    one copy runs. It has a host test with a scripted fake Wimp.
  - Repackaged the same day: the first version said "File name '.Task' not
    recognised" when `!FFmpeg` was started from the boot sequence
    (Configure > Boot > Look at). It used `FFmpeg$Dir` when a file was
    dropped, and that can hold a reference like `<Obey$Dir>` which by then
    points elsewhere. It now works out its full directory when it starts
    (`OS_FSControl` 37, else its own command line).

## 5.1.10-riscos4 (2026-09-27)

- **The real cause of the Pi crash** ("abort on data transfer", which
  `*Where` placed in VFPSupport; an EMT trap in `hl_motion` in the log):
  - FFmpeg's `ff_put_h264_chroma_mc2_neon` copied 2x2 chroma pixels with
    `ldrh` from a source that can be at an odd address. That happens in
    H.264 4x4 sub-partitions at whole-pixel chroma positions.
  - Big Buck Bunny 720p hits it within the first frames; the old test clips
    never used 4x4 partitions.
  - Byte loads now (patch 0014). Single-threaded ffmpeg crashed the same
    way, so it was never a thread or TaskWindow problem.
- **New "motion" test clips** (`tests/qemu/samples/mv_*`). They scroll and
  zoom, and are encoded with every partition size, B-frames, weighted
  prediction, MBAFF, CAVLC, 10-bit and 4:2:2 (H.264), plus HEVC, VP8, VP9,
  AV1, MPEG-4 qpel/4MV, interlaced MPEG-2, Theora, WMV2 and H.263.
  - All decode under the alignment-trapping QEMU with NEON output equal
    to C.
  - The fixed mc2 was compared with an x86 ffmpeg frame by frame.
- riscos3's change (switching the VFP context off around `Wimp_StartTask`)
  stays: UnixLib does the same, and it's correct. But it wasn't this
  crash.

## 5.1.10-riscos3 (2026-09-27)

- **ffplay from a TaskWindow crashed on the Pi** ("Internal error: abort on
  data transfer" in VFPSupport; the new ffplay's log showed an EMT trap in
  its video decoder thread). *Note (riscos4): the explanation below was
  wrong; the crash was the unaligned `ldrh` fixed in riscos4.* The ffplay in the TaskWindow started the new
  task with its own VFP (floating point) context still active. VFPSupport
  later saved that context to its old stack address, which by then
  belonged to the new ffplay, and corrupted it. ffplay now switches its
  context off around `Wimp_StartTask`, as UnixLib does before running
  another program (patch 0013).
- **Built with the fixed UnixLib from the Warzone 2100 port's toolchain**
  (caea90c3): the pthread ticker's code is in the RMA, so a thread switch
  can't jump into ffplay's memory while another task is paged in. ffplay
  runs several threads (reading, decoding, SDL's timer). Warzone 2100 hit
  exactly that abort.

## 5.1.10-riscos2 (2026-09-27)

- **`ffmpeg -f egl`:** a new output device that shows video through
  riscos-mesa's EGL, in a desktop window or the whole screen (optionally
  straight into screen memory). swscale converts and scales each frame
  into the surface in one pass.
- **ffegl:** a library for EGL and OpenGL programs. It plays a file with
  sound (SDL2 audio is the clock) into an EGL surface, an OpenGL texture
  or any 32bpp memory, and has pause, seek and loop. It is in the devkit
  (`ffegl.h`, `libffegl.a`), with two examples in
  FFmpeg-EGL-examples: `videowin` and `videocube`.
- **Textures without a copy:** with riscos-mesa 20.3.5-7pre12 or later,
  `ffegl_texture()` binds a sprite to the texture through an EGLImage
  (`EGL_KHR_image_pixmap`, `GL_OES_EGL_image`), and swscale writes each
  frame straight into it. Older riscos-mesa, or `FFEGL_NO_EGLIMAGE=1`,
  copies with `glTexSubImage2D`.
- **ffplay** converts and scales frames straight into its window surface,
  in the screen's format, instead of through an SDL texture and a second
  scale. `FFPLAY_SCALE` picks the scaler; `FFPLAY_RENDERER=sdl` gives the
  old path.
- **Fixes found by the new tests** (both also affect ffplay):
  - swscale's NEON YUV→RGBA store demanded 16-byte aligned
    destinations and would fault on RISC OS otherwise (patch 0009);
  - swscale's NEON converters reported 0 lines done, which callers took as
    failure (patch 0010).
- **ffplay in a TaskWindow:** riscos1 stopped with "Failed to create
  window or renderer: Wimp_Initialise failed: Window Manager is currently
  in use", because a TaskWindow can't open windows. ffplay now starts
  itself as a desktop task of its own (through the new `Task` Obey file,
  which sets the WimpSlot), with its messages in
  `<Wimp$ScrapDir>.ffplay/log`; `FFPLAY_NEWTASK=0` turns this off
  (patch 0013). `-f egl` gives a clear error there instead of taking over
  the screen (patch 0012).
- `ffmpeg -version` now says `5.1.10-riscos2` rather than a git hash.
- The programs are larger (about 31MB) because they include riscos-mesa's
  EGL and OpenGL; the WimpSlot is now 44MB.
- Built with the riscos-mesa 20.3.5-7pre12 devkit.

## 5.1.10-riscos1 (2026-09-27)

First release: FFmpeg 5.1.10 LTS for RISC OS on ARMv7 + NEON.

- Built with GCCSDK GCC 10.2 (`-O3`, `-mfpu=neon-vfpv3`,
  `-mtune=cortex-a72`, `-fstack-clash-protection`) as static AIF programs:
  `ffmpeg`, `ffprobe`, `ffplay`.
- With x264, dav1d 1.5.4, LAME 3.100, Opus 1.5.2 and Vorbis 1.3.7.
  `ffplay` uses riscos-mesa's SDL2 overlay without GL.
- **Alignment:** the NEON assembly of FFmpeg, dav1d and x264 is rewritten
  at build time so it can't fault with RISC OS's alignment checking on.
  The ARMv6 media routines are not used, and a few core-ARM loads and
  stores are patched (docs/ALIGNMENT.md). It was checked under a QEMU that
  traps like RISC OS: all three checkasm suites and 110 decode/encode jobs
  pass.
- **RISC OS file names** work for input and output (`SDFS::…`,
  `<Var$Dir>.…`), and a `/ext` suffix picks the output format.
- **Memory:** the heap is in the "FFmpeg Heap" dynamic area (512 MB
  maximum).
- **ffplay** converts frames to the screen's own 32bpp format with
  swscale's NEON code.
- **Bench:** an Obey file that compares NEON with plain C on your machine.
- Not tested on RISC OS hardware yet.
