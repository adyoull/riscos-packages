
[spec]

; Format and options of this spec file:
options = "+Freeciv-3.2-spec"

[info]

artists = "
    Tatu Rissanen <tatu.rissanen@hut.fi>
    Jeff Mallatt <jjm@codewell.com> (miscellaneous)
    GriffonSpade
"

[file]
gfx = "isotrident/unitcost"

[grid_main]

x_top_left = 1
y_top_left = 1
dx = 63
dy = 23
pixel_border = 1

tiles = { "row", "column", "tag"
;  0, 0, "upkeep.shield"
  0, 1, "upkeep.shield2"
  0, 2, "upkeep.shield3"
  0, 3, "upkeep.shield4"
  0, 4, "upkeep.shield5"
  0, 5, "upkeep.shield6"
  0, 6, "upkeep.shield7"
  0, 7, "upkeep.shield8"
  0, 8, "upkeep.shield9"
  0, 9, "upkeep.shield10"
;  1, 0, "upkeep.gold"
;  1, 1, "upkeep.gold2"
  1, 2, "upkeep.gold3"
  1, 3, "upkeep.gold4"
  1, 4, "upkeep.gold5"
  1, 5, "upkeep.gold6"
  1, 6, "upkeep.gold7"
  1, 7, "upkeep.gold8"
  1, 8, "upkeep.gold9"
  1, 9, "upkeep.gold10"
;  2, 0, "upkeep.food"
;  2, 1, "upkeep.food2"
  2, 2, "upkeep.food3"
  2, 3, "upkeep.food4"
  2, 4, "upkeep.food5"
  2, 5, "upkeep.food6"
  2, 6, "upkeep.food7"
  2, 7, "upkeep.food8"
  2, 8, "upkeep.food9"
  2, 9, "upkeep.food10"
;  3, 0, "upkeep.unhappy"
;  3, 1, "upkeep.unhappy2"
  3, 2, "upkeep.unhappy3"
  3, 3, "upkeep.unhappy4"
  3, 4, "upkeep.unhappy5"
  3, 5, "upkeep.unhappy6"
  3, 6, "upkeep.unhappy7"
  3, 7, "upkeep.unhappy8"
  3, 8, "upkeep.unhappy9"
  3, 9, "upkeep.unhappy10"
}
