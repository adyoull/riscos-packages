Racing car wheel model

Copyright © 2008 Eric Espie
Copyright © 2009 Bernhard Wymann

--

Copyleft: this work of art is free, you can redistribute
it and/or modify it according to terms of the Free Art license.
You will find a specimen of this license on the site
Copyleft Attitude http://artlibre.org as well as on other sites.
